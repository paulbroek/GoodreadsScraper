"""Settings.py, general settings for scrape_goodreads."""

from pathlib import Path

# __all__ = [
#     "CONFIG_FILE",
#     "VIDEOS_PATH",
#     "CAPTIONS_PATH",
#     "SPACY_MODEL",
# ]

######################
##### cfg paths ######
######################

CONFIG_FILE = "goodreads.cfg"

######################
##### File paths #####
######################

REPO_DIR = Path("/home/paul/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads")
DATA_DIR = REPO_DIR / "data"

TOP_AUTHORS_PATH = DATA_DIR / "top_authors.feather"
BOOKS_PATH = DATA_DIR / "books.feather"
AUTHORS_PATH = DATA_DIR / "authors.feather"
ALL_BOOKS_PATH = DATA_DIR / "all_books.feather"
MY_DOWNLOADS_PATH = DATA_DIR / "my_downloads.feather"

ALL_AUTHOR_ID_PATH = DATA_DIR / "all_authors.feather"

MODEL_PATH = DATA_DIR / "book_descriptions.model"
TOPICS_PATH = DATA_DIR / "book_descriptions.feather"
