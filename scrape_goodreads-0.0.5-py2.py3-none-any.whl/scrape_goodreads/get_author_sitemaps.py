"""get_author_sitemaps.py."""

import gzip
# import io
from pathlib import Path
from typing import Set
# from urllib import urlopen
from urllib import request

import requests  # type: ignore[import]
from bs4 import BeautifulSoup  # type: ignore[import]
from tqdm import tqdm  # type: ignore[import]

url = "https://www.goodreads.com/siteindex.author.xml"
xmlDict = {}

r = requests.get(url)
xml = r.text

soup = BeautifulSoup(xml)
sitemapTags = soup.find_all("sitemap")

print("The number of sitemaps are {0}".format(len(sitemapTags)))

for sitemap in sitemapTags:
    xmlDict[sitemap.findNext("loc").text] = sitemap.findNext("lastmod").text

print(xmlDict)

tempDir = Path("/tmp")

all_authors: Set[str] = set()

# extract author urls
for u in tqdm(xmlDict.keys()):
    outFilePath = tempDir / u.split('/')[-1][:-3]
    # url = 'http://dumps.wikimedia.org/enwiktionary/latest/enwiktionary-latest-all-titles-in-ns0.gz'
    # inmemory = io.StringIO(request.urlopen(u).read())

    response = request.urlopen(u)
    # fStream = gzip.GzipFile(fileobj=inmemory, mode='rb')
    # fStream = gzip.decompress(inmemory)

    out = gzip.decompress(response.read())
    sitemapSoup = BeautifulSoup(out)

    urls = sitemapSoup.find_all("loc")

    for url_ in urls:
        all_authors.add(url_.text)

    print(f"{len(all_authors)=:,}")
    
    # with open(outFilePath, 'wb') as outfile:
    #     outfile.write(out)
