""" 
    added by Paul

    scrapes popular list names from goodreads using bs4
"""

import requests
from bs4 import BeautifulSoup

MAXN = 9

titles = set()
for i in range(MAXN):
    print(f'{i=}')
    r = requests.get(f'https://www.goodreads.com/list/tag/health?page={i}')
    soup = BeautifulSoup(r.text, "html.parser")
    els =  soup.find_all(class_="listTitle")
        
    if not els:
        break

    for el in els:
        listTitle = el.attrs['href']
        listTitle = listTitle.replace('/list/show/','')

        titles.add(listTitle)

# to_file('titles.txt', titles)
def to_file(name, titles):
    """ write title names to file, so it can be read in bash and run a docker scrapy container for every list """
    
    with open(name, 'w') as f:
      f.write('\n'.join(titles))

