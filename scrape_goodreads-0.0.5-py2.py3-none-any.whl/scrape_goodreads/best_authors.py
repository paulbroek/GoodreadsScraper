"""best_authors.py.

compute a weighted average of (avg_rating, num_reviews, num_ratings) to filter out best authors from 120K author dataset
"""

import matplotlib.pyplot as plt
import pandas as pd
import pylab
import scipy.stats as stats
import seaborn as sns
from models import Author, psql
from rarc_utils.sqlalchemy_base import get_session
from scipy.special import softmax
from sklearn import preprocessing
from sqlalchemy.future import select  # type: ignore[import]

s = get_session(psql)()


def plot_dist(x):

    sns.set(rc={"figure.figsize": (8, 4)})
    # np.random.seed(0)
    # x = np.random.randn(100)
    ax = sns.distplot(x)
    # ax = sns.histplot(data=x)
    plt.show()

# plot_prob(df.n_num_ratings)
def plot_prob(x):
    stats.probplot(x, dist="norm", plot=pylab)
    pylab.show()

stmt = select(Author)

authors = s.execute(stmt).scalars().fetchall()
df = pd.DataFrame([a.as_dict() for a in authors])

# df["score"] =

# sample = df[["num_ratings"]].sample(1000)
df["num_ratings_bin"] = pd.qcut(df.num_ratings, 20, labels=False, duplicates='drop')
# plot_dist(sample)
# plot_dist(df.num_ratings_bin)

cols = ["avg_rating", "num_reviews", "num_ratings"]
norm_cols = [f"n_{c}" for c in cols]
bin_cols = [f"bin_{c}" for c in cols]
min_max_scaler = preprocessing.MinMaxScaler()
x_scaled = min_max_scaler.fit_transform(df[cols])
df[norm_cols] = x_scaled
df[bin_cols] = df[cols].apply(lambda x: pd.qcut(x, 5, labels=False, duplicates='drop'), axis=0)
# df[norm_cols] = df[norm_cols].apply(softmax, axis=1)
# cols_scaled = pd.DataFrame(x_scaled, columns=[f"n_{c}" for c in cols])
# df = pd.DataFrame(x_scaled)

df["score"] = 0.6 * df["bin_avg_rating"] + 0.2 * df.bin_num_reviews + 0.2 * df.bin_num_ratings
df = df.sort_values("score", ascending=True).reset_index(drop=True)
# df.head(10)
df[cols + ["score"]].head(10)

save = True
if save:
    df.to_feather("top_authors.feather")

df[cols]
