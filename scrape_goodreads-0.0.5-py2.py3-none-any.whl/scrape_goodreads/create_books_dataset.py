"""create_books_dataset.py.

get all books from postgres, and save as feather file

Run:
    ipy create_books_dataset.py -i -- -s
    
    # only load previously saved dataset
    ipy create_books_dataset.py -i -- -l
"""

import argparse

import pandas as pd
from rarc_utils.sqlalchemy_base import get_session
from scrape_goodreads.models import Book, psql
from scrape_goodreads.settings import BOOKS_PATH
from sqlalchemy.future import select  # type: ignore[import]

s = get_session(psql)()

def get_items() -> pd.DataFrame:
    """Get items from db."""
    stmt = select(Book)

    items = s.execute(stmt).scalars().fetchall()
    df = pd.DataFrame([i.as_dict() for i in items])

    return df

parser = argparse.ArgumentParser(
    description="topic_modeling_bertopic optional parameters"
)
parser.add_argument(
    "-l",
    "--load_dataset",
    action="store_true",
    default=False,
    help="Load feather dataset",
)
parser.add_argument(
    "-s",
    "--save_dataset",
    action="store_true",
    default=False,
    help="Save feather dataset",
)

if __name__ == "__main__":
    args = parser.parse_args()

    create_dataset = True

    if args.load_dataset:
        df = pd.read_feather(BOOKS_PATH)
        create_dataset = False

    if create_dataset:
        df = get_items()

    if create_dataset and args.save_dataset:
        df.to_feather(BOOKS_PATH)
