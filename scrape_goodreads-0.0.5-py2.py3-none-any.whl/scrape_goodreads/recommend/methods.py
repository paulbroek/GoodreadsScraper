"""methods.py, recommender helper methods."""

import logging
from typing import Any, Dict, List

import pandas as pd

logger = logging.getLogger(__name__)


def parse_my_downloads(
    items: List[Dict[str, Any]], df_books: pd.DataFrame
) -> pd.DataFrame:
    """Parse my_downloads to DataFrame."""
    downloads_df = pd.DataFrame(items).rename(columns={"genres_arr": "genres"})
    # not neccesary, since association records are unique on (book_id, genre_id)?
    # df["genres"] = df["genres"].map(set).map(list)

    # merge with df_books to include book title column
    df = pd.merge(downloads_df, df_books[["id", "title"]], left_on="id", right_on="id")

    return df


def compute_book_score(df: pd.DataFrame) -> pd.DataFrame:
    """Compute book score.

    Can be score of any type: put weight on avg_rating, num_review,
    or on overlap with preferred genres,
    and what more
    """
    df["score"] = (
        0.6 * df["bin_avg_rating"] + 0.2 * df.bin_num_reviews + 0.2 * df.bin_num_ratings
    )

    return df


def compute_genre_counts(df: pd.DataFrame) -> pd.DataFrame:
    """Get genre_counts.

    Example output:
                    count  in_pct_books
        Nonfiction    644      0.867925
        Science       421      0.567385
        Self Help     240      0.323450
        ...
    """
    assert "genres" in df.columns
    genres: List[str] = sum(df.genres.map(list).to_list(), [])
    genre_counts: pd.DataFrame = pd.Series(genres).value_counts().to_frame("count")
    genre_counts["in_pct_books"] = genre_counts["count"] / len(df)

    return genre_counts
