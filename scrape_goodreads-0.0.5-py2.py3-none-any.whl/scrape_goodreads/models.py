""" 
    based on:
         https://docs.sqlalchemy.org/en/14/orm/extensions/asyncio.html 

    create database 'trade' in psql (command line tool for postgres):
        (go inside psql) docker exec -it trade-postgres bash -c 'psql -U postgres -W'   ENTER PASSWORD, see yml file
        
        CREATE DATABASE "trade";

    now connect using:
        docker exec -it trade-postgres bash -c 'psql trade -U postgres -W'

    or directly, by installing postgres on linux (sudo apt-get -y install postgresql):
        psql -h 77.249.149.174 -d trade -U postgres -W
        psql -h 77.249.149.174 -d trade -U postgres (when using a password file: echo "77.249.149.174:5432:trade:postgres:PASSWORD" > ~/.pgpass   Don't forget to set permissions: chmod 600 ~/.pgpass)

    create some tables using (from ./rarc/rarc directory):
        ipython --no-confirm-exit ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/models.py -i -- --create 1

    list data:
        ipython --no-confirm-exit ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/models.py -i -- --create 0

    Create views in psql (for easy querying later):

        docker exec -it postgres-master bash -c 'psql goodreads -U postgres -f /greads_data/views.sql'

    Create triggers in psql, so that most views are automatically refreshed for incoming records:
    
        docker exec -it postgres-master bash -c 'psql goodreads -U postgres -f /greads_data/triggers.sql'

    Refresh a view:

        REFRESH MATERIALIZED VIEW vw_books;
        REFRESH MATERIALIZED VIEW vw_books_with_downloads;

    Show some books in psql:

        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language
        FROM        vw_books
        LIMIT       5;

    Show only books with nonzero cover_image url:

        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language, trunc_cover_image
        FROM        vw_books
        WHERE       cover_image is NOT NULL
        LIMIT       5;

    Show recently added books:
    
        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language, updated, trunc_cover_image
        FROM        vw_books
        ORDER BY    updated DESC
        LIMIT       5;    

    Show recently downloaded books:

        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language, updated, ndownload, trunc_cover_image
        FROM        vw_books_with_downloads
        ORDER BY    updated DESC
        LIMIT       5;   

    Show recent download_items:
        
        REFRESH MATERIALIZED VIEW vw_last_downloads;

        SELECT      *, date_trunc('seconds', NOW() - updated) AS updated_ago 
        FROM        vw_last_downloads
        WHERE       done = 't'
        LIMIT       15;

    Get only genre=='Science' books:

        SELECT book.title, genre.name AS genre_name
        FROM book_genre_association bga
        INNER JOIN book ON bga.book_id = book.id
        INNER JOIN genre ON bga.genre_id = genre.id
        WHERE genre.name = 'Science'
        LIMIT 10;

    Or all book data for one genre, easier for node API usage:

        SELECT book.*, author.name AS author_name, genre.name AS genre_name
        FROM book_genre_association bga
        INNER JOIN book ON bga.book_id = book.id
        INNER JOIN genre ON bga.genre_id = genre.id
        INNER JOIN author ON author.id = book.author_id
        WHERE genre.name = 'Science'
        LIMIT 10;

    Most used query: get all books and concatenate genres into a comma separated string (so react can filter on multiple genres per book)

        SELECT book.*, author.name AS author_name, string_agg(genre.name, ',') as genres
        FROM book_genre_association bga
        INNER JOIN book ON bga.book_id = book.id
        LEFT JOIN genre ON bga.genre_id = genre.id
        INNER JOIN author ON author.id = book.author_id
        GROUP BY book.id, author.id
        ORDER BY 
        LIMIT 10;

    Get popular book categories currently in database:

        SELECT genre.name, COUNT(DISTINCT genre.name) as genre_count
        FROM book_genre_association bga
        INNER JOIN genre
        ON bga.genre_id = genre.id
        GROUP BY genre.name
        ORDER BY genre_count DESC
        LIMIT 10;

    For migrations use alembic. First install `pip install psycopg2-binary` and `pip install alembic` in current conda environment. Run `alembic init alembic`  in this folder, 
    and update "alembic.ini" by changing sqlalchemy.url to `postgresql://postgres:mongo1991@77.249.149.174/goodreads`
        - update the env.py file by importing your model: 
            from trade_models import Base"
            target_metadata = Base.metadata"

        - Change something in the model below, and run 
            alembic revision --autogenerate -m "Add sum_amount column for Position"    for example
            Check the contents of the new alembic/versions/****Add_sum... file and if it correct run:

        - `alembic upgrade head` to commit all changes
        
        - Excellent documentations on: https://alembic.sqlalchemy.org/en/latest/autogenerate.html

"""

import argparse
import asyncio
import configparser
import logging
import os
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd
from rarc_utils.misc import AttrDict
from rarc_utils.sqlalchemy_base import \
    aget_str_mappings as aget_str_mappings_custom
from rarc_utils.sqlalchemy_base import async_main
from rarc_utils.sqlalchemy_base import create_many as create_many_custom
from rarc_utils.sqlalchemy_base import (did_change, did_increase,
                                        did_increase_len, get_async_session,
                                        get_session)
from rarc_utils.sqlalchemy_base import \
    get_str_mappings as get_str_mappings_custom
from sqlalchemy import (Boolean, Column, DateTime, Float, ForeignKey, Integer,
                        String, Text, UniqueConstraint, func)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.future import select  # type: ignore[import]
from sqlalchemy.orm import relationship
from sqlalchemy.schema import Table
from tqdm import tqdm  # type: ignore[import]

__location__ = os.path.realpath(
    os.path.join(os.getcwd(), os.path.dirname(__file__)))

LOG_FMT = "%(asctime)s - %(module)-16s - %(lineno)-4s - %(funcName)-16s - %(levelname)-7s - %(message)s"  # title
logger = logging.getLogger(__name__)
logger.info(f"{__location__=}")

parser  = configparser.ConfigParser()
parser.read(__location__ + "/goodreads.cfg")
psql  = AttrDict(parser['psql'])

Base = declarative_base()

author_genre_association = Table('author_genre_association', Base.metadata,
    Column('author_id', Integer, ForeignKey('author.id')),
    Column('genre_id', Integer, ForeignKey('genre.id')), # an author can have multiple genres, a genre can belong to multiple authors
    UniqueConstraint('author_id', 'genre_id')
)

book_genre_association = Table('book_genre_association', Base.metadata,
    Column('book_id', Integer, ForeignKey('book.id')),
    Column('genre_id', Integer, ForeignKey('genre.id')), # a book can have multiple genres, a genre can belong to multiple books
    UniqueConstraint('book_id', 'genre_id')
)

book_character_association = Table('book_character_association', Base.metadata,
    Column('book_id', Integer, ForeignKey('book.id')),
    Column('character_id', Integer, ForeignKey('character.id')), # a book can have multiple characters, a character can belong to multiple books
    UniqueConstraint('book_id', 'character_id')
)

book_place_association = Table('book_place_association', Base.metadata,
    Column('book_id', Integer, ForeignKey('book.id')),
    Column('place_id', Integer, ForeignKey('place.id')), # a book can have multiple places, a place can belong to multiple books
    UniqueConstraint('book_id', 'place_id')
)

class AuthorToScrape(Base):
    """AuthorToScrape

    An author Id fetched from sitemap https://www.goodreads.com/siteindex.author.xml (5M+ as of July 30 2022)
    This model is used for worker scrapers to see which author needs scraping
    """
    __tablename__ = "author_to_scrape"
    id          = Column(String, primary_key=True)
    last_scraped = Column(DateTime)
    nscrape     = Column(Integer, default=0, nullable=False)
    npage       = Column(Integer, nullable=False)
    lock        = Column(Boolean, default=False, nullable=False)

    nupdate = Column(Integer, default=0)
    # , onupdate=nupdate_count)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}
    # __table_args__ = (Index('index_updated', "updated", "is_open"), Index('index_created', "created", "is_open"))

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "AuthorToScrape(id={}, last_scraped={}, nscrape={}, npage={}, lock={})".format(self.id, self.last_scraped, self.nscrape, self.npage, self.lock)

class Author(Base):
    """ see https://github.com/havanagrawal/GoodreadsScraper
        for all fields that get scraped and can be used in the data model
    """
    __tablename__ = "author"
    id          = Column(Integer, primary_key=True)
    genres      = relationship("Genre", uselist=True, secondary=author_genre_association, lazy=True)
    url         = Column(String, nullable=False)
    name        = Column(String, nullable=False)
    birth_date  = Column(String, nullable=True)
    death_date  = Column(String, nullable=True)
    avg_rating  = Column(Float, nullable=True)
    num_reviews = Column(Integer, nullable=True)
    num_ratings = Column(Integer, nullable=True)
    about       = Column(String, nullable=True)

    nupdate = Column(Integer, default=0)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # title + author together should be unique for now
    UniqueConstraint('name', 'birth_date', name='unique_author')

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}
    # __table_args__ = (Index('index_updated', "updated", "is_open"), Index('index_created', "created", "is_open"))

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Author(name={}, avg_rating={:.2f}, num_reviews={}, num_ratings={}, url={})".format(self.name, self.avg_rating, self.num_reviews, self.num_ratings, self.url,)

class Book(Base):
    """ see https://github.com/havanagrawal/GoodreadsScraper
        for all fields that get scraped and can be used in the data model
    """
    __tablename__ = "book"
    id                  = Column(Integer, primary_key=True)
    author_id           = Column(Integer, ForeignKey("author.id"))
    author              = relationship("Author", uselist=False, lazy='selectin')
    genres              = relationship("Genre", uselist=True, secondary=book_genre_association, lazy=True) #lazy='selectin') # lazy='joined') # , lazy='subquery')
    url                 = Column(String, nullable=False)
    cover_image         = Column(String, nullable=True)
    title               = Column(String, nullable=False)
    description         = Column(Text, nullable=True)
    avg_rating          = Column(Float, nullable=True)
    custom_rating       = Column(Float, nullable=True)
    num_reviews         = Column(Integer, nullable=True)
    num_ratings         = Column(Integer, nullable=True)
    num_pages           = Column(Integer, nullable=True)
    language            = Column(String, nullable=True)
    publish_date        = Column(String, nullable=True)
    original_publish_year = Column(Integer, nullable=True)
    characters          = relationship("Character", uselist=True, secondary=book_character_association, lazy=True) 
    places              = relationship("Place", uselist=True, secondary=book_place_association, lazy=True) 
    isbn                = Column(String, nullable=True)
    isbn13              = Column(String, nullable=True)
    rating_histogram    = relationship("RatingHistogram", uselist=False, backref="book")
    downloaded_items    = relationship("DownloadItem", uselist=True, back_populates='book', lazy='selectin')

    # title + author together should be unique for now
    UniqueConstraint('title', 'author_id', name='unique_title_author')

    nupdate = Column(Integer, default=0)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def as_joined_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def as_big_dict(self):
        return {c: getattr(self, c) for c in dir(self) if not c.startswith(('_','__','registry'))}

    def from_json(self):
        # todo: move code from process_items.book_from_json to here
        raise NotImplementedError

    def update_from_json(self, other: Dict[str, Any], skipCols=('id','created','updated','nupdate')) -> int:
        """Update object by overwriting fields from `other` object.

        Dismiss id, created and updated fields
        """
        nupdated = 0
        for attr in set(self.__table__.columns.keys()) - set(skipCols):
            newval = other.get(attr, None)
            if newval is not None:
                setattr(self, attr, newval)
                nupdated += 1

        return nupdated

    @staticmethod
    def did_change_diff(existing, new) -> Dict[str, bool]:
        """Return did_X per key.

        do not include `custom_rating` for now, since it is manually added
        not including it in a new item would overwrite it 

        and: I cannot updated nested data yet, since it is not an attribute of the object, see
            `update_from_json` above
        """
        return {
            "description" : did_increase_len(existing, new, key="description"),
            "avg_rating": did_change(existing, new, key="avg_rating"),
            # "custom_rating": did_change(existing, new, key="custom_rating"),
            "num_reviews": did_increase(existing, new, key="num_reviews"),
            "num_ratings": did_increase(existing, new, key="num_ratings"),
            "num_pages": did_increase(existing, new, key="num_pages"),
            # "characters": did_increase_len(existing, new, key="characters"),
            # "places": did_increase_len(existing, new, key="places"),
        }

    @classmethod
    def did_change_pipeline(cls, existing, new) -> bool:
        """Return True if any of the pipeline items changed in the desired way."""
        if any(cls.did_change_diff(existing, new).values()):
            return True

        return False

    def __repr__(self):
        return "Book(title={}, author={}, avg_rating={:.2f}, custom_rating={}, nreview={}, len_descrip={}, language={}, ngenre={}, ndownload={}, created={})".format(self.title, self.author.name, self.avg_rating, self.custom_rating, self.num_reviews, len(self.description) if self.description is not None else 0, self.language, len(self.genres), len(self.downloaded_items), self.created)

class Genre(Base):
    """ GoodReads genres are simply strings, but a book can have many genres """

    __tablename__ = "genre"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False)
    
    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Genre(name={})".format(self.name) # rate={:.5f}  --> what to do when rate is None?

class Character(Base):
    """ GoodReads characters are simply strings, but a book can contain many characters """

    __tablename__ = "character"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False, unique=True)
    
    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Character(name={})".format(self.name) # rate={:.5f}  --> what to do when rate is None?

class Place(Base):
    """ GoodReads places are simply strings, but a book can contain many places """

    __tablename__ = "place"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False, unique=True)
    
    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Place(name={})".format(self.name) # rate={:.5f}  --> what to do when rate is None?

class RatingHistogram(Base):
    """ GoodReads rating can be between 1 and 5 stars 
        a RatingHistogram is the aggregating of all ratings, since I'm not saving rating entries
    """

    __tablename__ = "rating_histogram"
    id          = Column(Integer, primary_key=True)
    book_id     = Column(Integer, ForeignKey("book.id"))
    star1       = Column(Integer, nullable=True)
    star2       = Column(Integer, nullable=True)
    star3       = Column(Integer, nullable=True)
    star4       = Column(Integer, nullable=True)
    star5       = Column(Integer, nullable=True)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def rating_as_dict(self):
        # star_cols = [ getattr(self, c.name) for c in self.__table__.columns}]
        return {f"{i}": getattr(self, f"star{i}") for i in range(1,6)}

    def __repr__(self):
        return "RatingHistogram(book_title={}, rating_histogram={})".format(getattr(self.book, 'title', None), self.rating_as_dict()) # rate={:.5f}  --> what to do when rate is None?

class DownloadItemType(Base):
    """ DownloadItemType can be pdf, epub, mobi, ... """

    __tablename__ = "download_item_type"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False, unique=True)
    
    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "DownloadItemType(name={})".format(self.name)

class DownloadItem(Base):
    """ DownloadItem represents a completed book download, with a (zlib) name, parent book id and a DownloadItemType """

    __tablename__   = "download_item"
    id              = Column(Integer, primary_key=True)
    book_id         = Column(Integer, ForeignKey("book.id"))
    book            = relationship("Book", uselist=False, lazy='selectin')
    tag             = Column(String, unique=False) # id from outside, to quickly fetch items
    zlib_name       = Column(String, nullable=False, unique=False)
    zlib_authors    = Column(String, nullable=True, unique=False)
    location        = Column(String, nullable=True, unique=False) # storage bucket address, optional
    file_name       = Column(String, nullable=True, unique=False) # file_name in the storage bucket
    file_type_id    = Column(Integer, ForeignKey("download_item_type.id"))
    file_type       = relationship("DownloadItemType", uselist=False, lazy='selectin')
    file_size_mb    = Column(Float)
    pct_done        = Column(Integer, unique=False, default=0)
    nupdate         = Column(Integer, unique=False, default=1) 
    done            = Column(Boolean, unique=False, default=False)
    dummy           = Column(Boolean, unique=False, default=False)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())
    
    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "DownloadItem(zlib_name={}, zlib_authors={}, book_title={}, file_type={}, file_name={}, file_size_mb={}, location={}, tag={}, pct_done={}, done={}, dummy={})".format(self.zlib_name, self.zlib_authors, getattr(self.book, 'title', None), self.file_type, self.file_name, self.file_size_mb, self.location, self.tag, self.pct_done, self.done, self.dummy)

# str_mappings = asyncio.run(aget_str_mappings(psql))
async def aget_str_mappings(psqConfig, models=(Genre, Character, Place, Author, DownloadItemType)):

    return await aget_str_mappings_custom(psqConfig, models)

# str_mappings = get_str_mappings(s)
def get_str_mappings(psqConfig, models=(Genre, Character, Place, Author, DownloadItemType)):

    return get_str_mappings_custom(psqConfig, models)

async def set_download_item(item):
    """Add zlib downloaded item to a goodreads Book.
    
    this prevents you from duplicate downloading a zlib book
    """
    raise NotImplementedError

def any_dict(book, unpackMethod):
    method = getattr(book, unpackMethod)

    if callable(method):
        return method.__call__()

    return method

def get_all(session, model=Book, n=None, hours_ago=None, to='list', indexCol='updated', unpackMethod='as_dict'):
    # assert issubclass(Base, model)
    assert type(Base) == type(model), f"{type(model)=}, should be DeclarativeMeta"
    assert to in (toTypes:=('list','pandas')), f"{to=} not in {toTypes=}"
    stmt_ = session.query(model)

    if model is Book:
        stmt_ = stmt_.join(Author)

    # bres_ = list(session.execute(stmt_).scalars())
    if hours_ago is not None:
        # assert isinstance(hours_ago, int)
        hours_ago = int(hours_ago)
        from_date = datetime.utcnow() - timedelta(hours=hours_ago)
        from_date_str = from_date.strftime("%Y-%m-%d %H:%M")
        assert isinstance(from_date_str, str)
        bres_ = stmt_.filter(func.date(model.updated) >= from_date_str)
    elif n is None:
        bres_ = stmt_.all()
    else:
        bres_ = stmt_.order_by(model.created.desc()).limit(n)

    if to=='pandas':
        assert hasattr(model, unpackMethod), f"{model=} does not have {unpackMethod=}"
        df = pd.DataFrame(map(lambda book: any_dict(book, unpackMethod), bres_))
        df.index = pd.DatetimeIndex(df[indexCol])
        return df

    return bres_

def count_ndownload(session, hours=24) -> int:
    """Count the number of downloaded items for a given interval 'hours'."""
    hours = int(hours)
    query = f"""SELECT COUNT(*) FROM download_item WHERE done='t' AND updated  >= NOW() - '{hours} hour'::INTERVAL;"""

    res: List[int] = session.execute(query).fetchone()
    
    return res[0]

def get_download_items_by_book(session, book_id, file_type_id=None, is_done=False):
    """Get download items by book.
        
    optionally also by file_type_id
    """
    query = "SELECT COUNT(*) FROM download_item WHERE book_id={}".format(book_id)
    if is_done:
        query += " AND done='t'"
    if file_type_id is not None:
        assert isinstance(file_type_id, int), f"{type(file_type_id)=}, should be int"
        query += f" AND file_type_id={file_type_id}"

    res = session.execute(query).fetchone()

    return res[0]

def get_download_item_types(session) -> Tuple[dict, dict]:
    """Return dict and inverted dict for download_item_type.
       
    example:
     ({1: 'PDF', 2: 'EPUB'}, {'PDF': 1, 'EPUB': 2})

    """
    query = """ SELECT * FROM download_item_type; """

    res = session.execute(query).fetchall()

    return dict(res), dict(r[::-1] for r in res)

def find_by_goodreads_id(goodreads_id: str, session) -> Optional[dict]:
    """Find books by goodreads id, the id is the string after https://www.goodreads.com/book/show/."""
    assert isinstance(goodreads_id, str)
    query = """ SELECT book.*, author.name AS author_name FROM book 
                INNER JOIN author ON author.id = book.author_id
                WHERE book.url LIKE '%/show/{}%'; 
            """.format(goodreads_id)

    res = session.execute(query).fetchone()

    if res is None:
        return res

    return res._asdict()

def get_download_items_by_book_id(book_id: int, session) -> Optional[List[dict]]:

    assert isinstance(book_id, int)

    query = """ SELECT DISTINCT di.book_id, di.zlib_name, di.done, dit.name AS di_type
                FROM download_item as di
                LEFT JOIN download_item_type AS dit ON dit.id = di.file_type_id
                WHERE di.book_id = {} AND di.done; 
            """.format(book_id)

    res = session.execute(query).fetchall()

    if len(res) == 0:
        return None

    return [r._asdict() for r in res]

async def create_many(*args, **kwargs) -> None:
    """Create many of any model type: Character, Genre, Places, Author, etc.
        
    Todo:   filtering out existing names only works for Category models, author is unique by name + birth_date,
            so it needs a different implementation
    """
    # print `Book` items if less than 20
    kwargs['printCondition'] = lambda model, items: model is Book and 0 < len(items) <= 20

    return await create_many_custom(*args, **kwargs)

# asyncio.run(set_custom_rating(async_session))
async def set_custom_rating(async_session, maxRow=None) -> None:
    """Retrieve all books, and sets a custom_rating.
    
    what works for now: inverse quantile cut (qcut) books based on num_ratings
    and substract that value from the avg_rating

    so F_custom_rating(x) =  avg_rating + 0.2 - num_ratings_bin / 9
    """
    # use node api to request books
    # --> unsafe, it skips books without cover_image urls
    # response = requests.get('http://localhost:3001/books/')
    # books = json.loads(response.text)

    # retrieve book by id and update book.custom_rating
    async with async_session() as session:
        psql_res = await session.execute(select(Book))
        psql_books = list(psql_res.scalars())
        books = [b.as_dict() for b in psql_books]

        df = pd.DataFrame(books)
        df.index = df['id']

        print(f"{df.head()[['title','avg_rating','id']]}")

        df['num_ratings_bin'] = pd.qcut(df.num_ratings, 10, labels=list(reversed(range(10))))
        df['custom_rating'] = df.apply(lambda row: row['avg_rating'] + 0.2 - row['num_ratings_bin'] / 9, axis=1)

        # for row in tqdm(df.itertuples(), mininterval=2):
        for i, book in enumerate(tqdm(psql_books, mininterval=1)):
            # print(f'{book.title=}')
            # book = session.query(Book).get(row.id)
            book.custom_rating = df.loc[book.id].custom_rating

            if maxRow is not None and i > maxRow:
                break

        # update all books at once
        await session.commit()

        nupdated = len(df) if maxRow is None else maxRow
        logger.info(f"updated {nupdated:,} rows")

async def create_initial_items(async_session) -> None:

    async with async_session() as session:
        await create_many(session, Character, {a: dict(name=a) for a in ['tom','tim','ian','bert']})
        await create_many(session, Genre, {a: dict(name=a) for a in ['Fiction','Action']})
        await create_many(session, DownloadItemType, {a: dict(name=a) for a in ['PDF','EPUB']})


if __name__ == "__main__":

    CLI=argparse.ArgumentParser()
    CLI.add_argument(
      "-v", "--verbosity", 
      type=str,         
      default='info',
      help=f"choose debug log level: ... " # {', '.join(loggingLevelNames())}
    )
    CLI.add_argument(
      "--create",    # get signals, don't send orders
      type=int,         
      default=0,
    )
    CLI.add_argument(
      "--use_rarc", 
      action='store_true',         
      default=False,
      help="import rarc package, or use basic logger"
    )

    cargs = CLI.parse_args()

    if cargs.use_rarc:        
        try:
            from utils.log import setup_logger, set_log_level, loggingLevelNames
        except:
            from rarc.utils.log import setup_logger, set_log_level, loggingLevelNames

        log_level   = cargs.verbosity.upper()
        logger      = setup_logger(cmdLevel=logging.DEBUG, saveFile=0, savePandas=0, color=1, fmt=LOG_FMT)
        set_log_level(logger, level=log_level, fmt=LOG_FMT)
    else:
        # use basic logger
        logging.basicConfig(level=logging.INFO, format=LOG_FMT)
        logger.info("using basic config logger")

    if cargs.create:
        print('create models')
        asyncio.run(async_main(psql, base=Base, dropFirst=True))

    else:
        print('get data')
        # data = asyncio.run(get_data2(psql))
        # raise NotImplementedError

    if 1:
        print('create data')
        async_session = get_async_session(psql)
        # asyncio.run(create_many(async_session, Character, ['tom','tim','ian','bert']))
        # asyncio.run(create_many(async_session, Genre, ['Fiction','Action']))
        asyncio.run(create_initial_items(async_session))

    s = get_session(psql)()
    # get some Characters, as a test
    stmt = select(Character).filter()
    cres = list(s.execute(stmt).scalars())

    stmt = s.query(Book) # Book.title
    bres = list(s.execute(stmt).scalars())
