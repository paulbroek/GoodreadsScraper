"""book_scraper_bot.py.

connecting to redis 'goodsreads_to_scrape' list through telegram bot
user can request goodreads titles to scrape, by simply passing an url

more help: 
    https://thepythoncorner.com/posts/2021-01-16-how-create-telegram-bot-in-python/

run bot locally:
    ipy scrape_goodreads/book_scraper_bot.py -i -- --dryrun
    ipy scrape_goodreads/book_scraper_bot.py -i --

todo:
    - [X] show list of commands
    - [X] show list of items to be scraped
    - [ ] (optional) show thumbnails of items to scrape
    - [X] scrape automatically through this bot (it runs process_items -> create_many)
    - [ ] ...
"""
import argparse
import json
import logging
import re
import traceback
import uuid
from datetime import datetime
from enum import Enum
from pprint import pprint
from time import sleep
from typing import List, Optional
from urllib.request import Request, urlopen

import pandas as pd
import redis
import timeago  # type: ignore[import]
from python_on_whales import docker
from rarc.config.redis import redis as rk  # type: ignore[import]
from rarc_utils.log import loggingLevelNames, setup_logger
from rarc_utils.sqlalchemy_base import get_session
from rarc_utils.telegram_bot import get_handler_docstrings
from scrape_goodreads.models import (DownloadItem, find_by_goodreads_id,
                                     get_all, get_download_item_types,
                                     get_download_items_by_book,
                                     get_download_items_by_book_id, psql)
from telegram.ext import CommandHandler, Filters, MessageHandler, Updater

psql_session = get_session(psql)()

log_fmt = "%(asctime)s - %(module)-16s - %(lineno)-4s - %(funcName)-16s - %(levelname)-7s - %(message)s"  # name
logger = setup_logger(
    cmdLevel=logging.INFO, saveFile=0, savePandas=0, jsonLogger=0, color=1, fmt=log_fmt
)

TOKEN = "5090153909:AAFxvTH-_IgTuQoupjUnaaJ4_ZO4U2rug04"
TO_SCRAPE_KEY = "goodreads_to_scrape"

# setup updating together with our telegram api token
updater = Updater(TOKEN, use_context=True)
# get the dispatcher to register handlers
dp = updater.dispatcher

BOOKS_WANTED_KEY = "books_wanted2"

BEST_MATCHES = "best_matches"
ZLIB_TRUNC_LEN = 20

API_HOST = "192.168.178.46"

rs = redis.Redis(
    # host=rk.REDIS_HOST,
    host=API_HOST,
    port=rk.REDIS_PORT,
    password=rk.REDIS_PASS,
    db=4,
    decode_responses=True,
)


class State(Enum):

    DEFAULT = 0
    PARSE_ZLIB_TO_DOWNLOAD = 1


def defaultState():
    return State.DEFAULT


def defaultStateContext():
    return dict()


def resetState():
    return defaultState(), defaultStateContext()


STATE, STATE_CONTEXT = resetState()

#######################
####  helper methods
#######################

book_id_pattern = re.compile(r".+show/(.*)$")
book_id_with_query_pattern = re.compile(r".+show/(.*)\?")

match_any_url1 = re.compile(r"https://(.+)\n")
match_any_url2 = re.compile(r"https://(.+)$")


def log_and_reply(update, text: str, how="text") -> None:
    """Log text message and reply html/text to user."""
    logger.info(text)
    how_ = f"reply_{how}"
    assert how_ in dir(update.message), f"method '{how_}' does not exist"
    getattr(update.message, how_).__call__(text)


def parseUrl(url: str) -> Optional[str]:
    """Parse url to goodreads book_id.

    example:
            https://www.goodreads.com/book/show/230510.The_New_Science_of_Strong_Materials?ac=1&from_search=true&qid=psT3Ic51Ta&rank=1
    or      https://www.goodreads.com/book/show/230510.The_New_Science_of_Strong_Materials

    parses to:
            230510.The_New_Science_of_Strong_Materials
    """
    res = book_id_with_query_pattern.search(url) or book_id_pattern.search(url)

    if res is None:
        logger.error(f"could not extract book_id from {url=}")
        return None

    return res.group(1)


def pushBook(goodreads_id: str) -> str:
    """Push book_to_scrape to redis.

    checks if book exists
    """
    # check if id exists in postgres
    match: Optional[dict] = find_by_goodreads_id(goodreads_id, psql_session)

    if match is not None:
        msg = "goodreads_id \n<i>{}</i> \nalready exists in <b>postgres</b>".format(
            goodreads_id
        )

        # also print what types of books exists in postgres
        book_id = match["id"]
        distinct_download_items: Optional[List[dict]] = get_download_items_by_book_id(
            book_id, psql_session
        )
        logger.info(f"distinct_download_items: {distinct_download_items}")

        if distinct_download_items is not None:
            ddf = pd.DataFrame(distinct_download_items)

            downloaded_types_fmt = ", ".join(ddf.di_type.to_list())
            msg += "\navailable types: <b>{}</b>".format(downloaded_types_fmt)

    # or in redis
    elif goodreads_id in rs.lrange(TO_SCRAPE_KEY, 0, -1):
        msg = "goodreads_id \n<i>{}</i> \nalready exists in <b>redis</b>".format(
            goodreads_id
        )

    # push id to redis
    else:
        try:
            rs.lpush(TO_SCRAPE_KEY, goodreads_id)
            msg = "pushed \n<i>{}</i> \nto '{}'".format(goodreads_id, TO_SCRAPE_KEY)
        except Exception as e:
            msg = f"cannot push goodreads_id to redis. {e=!r}"

    return msg


def match_push_book(text: str) -> Optional[str]:
    msg = None
    res = match_any_url1.search(text) or match_any_url2.search(text)
    if res is not None:
        url = res.group(1)
        book_id = parseUrl(url)
        if book_id is not None:
            msg = pushBook(book_id)

    return msg


#####################
####    handlers
#####################


def start(update, context):
    """Send welcome message."""
    # send a message once the bot is started/start command is ran
    update.message.reply_text("Welcome to Book Scraper!")


def help_(update, context):
    """Show a list of available commands."""
    ALL_HANDLERS = list(get_handler_docstrings(dp, sortAlpha=True).keys())
    # send a message once the command /hello is keyed
    # update.message.reply_text(f"{dir(context)=}")
    commands = "/" + "\n/".join(ALL_HANDLERS)
    update.message.reply_text(f"available commands: \n\n{commands}")


# for error debugging
def error(update, context):
    logger.warning(
        'Update "%s" caused error "%s \n%s"',
        update,
        context.error,
        traceback.format_exc(),
    )


def parse(update, context):
    """Parse book_id from goodreads url.

    accepts url parameter, or if passed without, accepts a message with url(s)
    """
    msg = "please enter an url"

    if len(context.args) > 0:
        book_id = parseUrl(context.args[0])
        msg = f"parsed book_id: {book_id}"

    update.message.reply_text(msg)


def add(update, context):
    """Parse and add to 'goodreads_to_scrape', if new."""
    msg = "please enter an url"

    if len(context.args) > 0:
        book_id = parseUrl(context.args[0])

        if book_id is None:
            msg = f"could not parse book_id from url"
        else:
            msg = pushBook(book_id)

    update.message.reply_html(msg)


def addw(update, context):
    """Query zlib for epub/pdf books, and ask user which items to add to wanted items in redis."""
    global STATE, STATE_CONTEXT
    msg = "please enter book_id"
    # msg = dir(update.message)

    if len(context.args) > 0:
        book_id = context.args[0]

        # verify that book_id exists in postgres
        match: Optional[dict] = find_by_goodreads_id(book_id, psql_session)

        if match is None:
            msg = f"please add {book_id=} to postgres first"

        else:
            # lookup zlib titles through django api

            reqBody = {
                "content": {"title": match["title"], "author": match["author_name"]}
            }
            jsondata = json.dumps(reqBody)
            reqdata = jsondata.encode("utf-8")
            logger.info(f"{match=}")

            # todo: move api host to settings file
            url = f"http://{API_HOST}:8000/api/query_zlib"
            request = Request(url, data=reqdata)
            with urlopen(request) as conn:
                res = conn.read().decode()

            logger.info(f"{res=}")

            json_res = json.loads(res)

            logger.info(f"{json_res=}")
            pprint(json_res)

            msg = "to be implemented"

            if BEST_MATCHES in json_res:
                big_df = pd.DataFrame(json_res[BEST_MATCHES])

                df = big_df.loc[:, ["title", "fileType", "authors"]].copy()
                # truncate `title` and `authors` cols
                df[["title", "authors"]] = df[["title", "authors"]].apply(
                    lambda x: x.str.slice(0, ZLIB_TRUNC_LEN), axis=0
                )

                # df['authors'] = df['authors'].str.slice(0, ZLIB_TRUNC_LEN)

                table_html = df.to_string()
                msg = f"results: \n\n <pre>{table_html}</pre> \n\nEnter index of row you want to scrape, or send 'all' to add all items to wanted list"

                # todo: change state to 'waiting_for_zlib_user_input', and wait for user input in text(), then send it to wanted items
                STATE = State.PARSE_ZLIB_TO_DOWNLOAD
                STATE_CONTEXT["df"] = big_df
                STATE_CONTEXT["book"] = match

    update.message.reply_html(msg)


def items(update, _):
    """Get number of to_scrape items in redis."""
    res = rs.lrange(TO_SCRAPE_KEY, 0, -1)
    items_str = "\n".join(res)
    ITEMS = "item" if len(res) == 1 else "items"

    update.message.reply_html(
        f"<b>{len(res)}</b> to_scrape {ITEMS} currently in redis: \n\n{items_str}"
    )


could_not_restart_template = (
    "could not restart {}. {!r} \n\nis the bot running from same host as docker?"
)


def scrape(update, _):
    """Run scraper through docker, and send items to postgres afterwards."""
    container_name = "scrape-goodreads-redis"

    try:
        docker.restart(container_name)
        msg = f"restarted {container_name}"
    except Exception as e:
        msg = could_not_restart_template.format(container_name, e)

    # todo: automatically inform user when scrape results are received in .jl files

    update.message.reply_html(msg)


def to_postgres(update, _):
    """Run `create_many items`.

    todo: automatically run after scrape?
    """
    container_name = "create-books-from-json"

    restart_success = False
    try:
        docker.restart(container_name)
        restart_success = True
        msg = f"restarted {container_name}"

    except Exception as e:
        msg = could_not_restart_template.format(container_name, e)

    update.message.reply_text(msg)

    # userdocker.logs to forward log output to user
    if restart_success:
        sleep(5)
        # message if often too long, take the tail
        logs = docker.logs(container_name, tail=25)
        msg = f"logs: \n{logs}"

        update.message.reply_text(msg)


def clear(update, _):
    """Clear items in to_scrape list.

    should only be allowed to run when items have been scraped. how to check this?
    --> use a pipeline
    """
    msg = "not implemented"

    try:
        nitem = rs.llen(TO_SCRAPE_KEY)
        rs.delete(TO_SCRAPE_KEY)
        msg = "deleted all {} items from list '{}'".format(nitem, TO_SCRAPE_KEY)
    except Exception as e:
        msg = f"cannot delete redis list. {e=!r}"

    update.message.reply_html(msg)


def make_bold(x):
    return f"<b>{x}</b>" if not isinstance(x, str) or not x.startswith("<b>") else x


# wanted_items = filter_wanted_items()
def filter_wanted_items():  #  -> List[download_item]:
    """Download items from 'wanted' list in Redis, until error pops up (you reached your daily limit)."""
    # get last N items from 'wanted' list
    wanted_items = rs.zrevrangebyscore(
        BOOKS_WANTED_KEY, "+inf", "-inf", start=0, num=100
    )
    logger.info(f"got {len(wanted_items)} wanted_items")  # \n{wanted_items=}

    # parse items
    wanted_items = [json.loads(item) for item in wanted_items]

    # get mappings of {download_item_type.name: download_item_type.id} and the reverse
    _, rev_dit = get_download_item_types(psql_session)

    # check if download_item exists (safety check)
    for wanted_item in wanted_items:
        # query postgres
        wanted_item["fileTypeId"] = rev_dit[wanted_item["fileType"]]
        wanted_item["keep"] = False

        res = get_download_items_by_book(
            psql_session,
            wanted_item["book_id"],
            wanted_item["fileTypeId"],
            is_done=True,
        )
        # logger.info(f'{res=}')
        if res == 0:
            wanted_item["keep"] = True

    wanted_items = [item for item in wanted_items if item["keep"]]
    logger.info(f"I have {len(wanted_items)} wanted_items")

    return wanted_items


def lastn(update, _):
    """Return overview of last downloaded books."""
    # trigger function does this now. see triggers.sql
    # psql_session.execute(
    #     "REFRESH MATERIALIZED VIEW vw_last_downloads;"
    # )

    query_res = psql_session.execute(
        "SELECT *, NOW() - updated AS updated_ago FROM vw_last_downloads WHERE done='t' LIMIT 100;"
    )
    # or compute `allowed` col directly in postgres: SELECT *, date_trunc('seconds', NOW() - last_updated) AS last_updated_ago,  success_pct > 0.8 AND success_sum >= 10 AS done FROM vw_last_downloads;
    last_dis = query_res.mappings().fetchall()
    df = pd.DataFrame(last_dis)
    cols = (
        "greads_author",
        "avg_rating",
        "num_reviews",
        "file_type",
        "zlib_name",
        "updated_ago",
    )
    ldf = (
        df.loc[:10, cols]
        .copy()
        .rename(
            columns={"avg_rating": "arat", "file_type": "type", "num_reviews": "nrev"}
        )
    )

    ldf["time_ago"] = ldf.updated_ago.map(
        lambda x: timeago.format(x, datetime.utcnow()), na_action="ignore"
    )  # time_ago displays in pretty way (like docker cli): 1 week ago, 12 minutes ago, etc.
    del ldf["updated_ago"]

    # df[["success_pct", "success_sum"]] = df[["success_pct", "success_sum"]].astype("float")
    # df["done"] = np.where((df.success_pct > 0.8) & (df.success_sum >= 8), 1, 0)

    logger.info(f"last download_item df=\n{df}")

    table_html = ldf.to_string()
    last_dis_msg = f"<pre>{table_html}</pre>"

    update.message.reply_html(last_dis_msg)


def status(update, _):
    """Print status of download process.

    how many books were downloaded past 24 hour, past week, ..

    print a msg like:

                   failed  success  total
        Mon 28-03       0        7      7
        Tue 29-03       0        7      7
        Wed 30-03       0        3      3
        Thu 31-03       4       10     14
        Fri 01-04       0        7      7
        Sat 02-04       0        7      7
        Sun 03-04       0       14     14
        TOTAL           4       55     59
    """
    # this works, but you cannot filter out items per day
    # ndownload_today = count_ndownload(psql_session)
    # ndownload_week = count_ndownload(psql_session, hours=24*7)

    # more general approach (eventually you want to group by month, year, etc..)
    # done: distinguish between 'done' and 'tried', groupby ('weekday', 'done')
    # todo: move the groupby functionality to models.py?

    show_failed_attempts = True
    add_total_row = True
    highlight_in_bold = (
        False  # highlight both success and total columns with bold markup
    )
    # best to send image when using markup inside table

    df = get_all(
        psql_session, DownloadItem, hours_ago=7.0 * 24, to="pandas"
    ).sort_index()
    df_done = df[df.done]

    # and group by week day
    df["updated_floor"] = df.updated.apply(
        lambda x: x.replace(hour=0, minute=0, second=0, microsecond=0)
    )
    if show_failed_attempts:
        by_weekday_done = df.groupby([df.updated_floor, "done"], as_index=True)
        done_per_day = by_weekday_done["id"].count()
        done_per_day = (
            done_per_day.unstack(fill_value=0)
            .rename(columns={False: "failed", True: "success"})
            .astype(int)
        )
        done_per_day["total"] = done_per_day.sum(axis=1)
        done_per_day.columns.name = ""
    else:
        by_weekday = df_done.groupby(df_done.updated.dt.weekday, as_index=False)
        done_per_day = by_weekday["id"].count().rename(columns={"id": "count"})

    # done_per_day.index = done_per_day.index.map(lambda x: f"{x.strftime('%A '):<12}" + x.strftime('%d-%m')) # Monday 28-03
    done_per_day.index = done_per_day.index.map(
        lambda x: x.strftime("%A")[:3] + x.strftime(" %d-%m")
    )  # Mon 28-03, or use '%A' for just weekday names
    done_per_day.index.name = ""

    if add_total_row:
        done_per_day = done_per_day.append(done_per_day.sum(axis=0).to_frame("TOTAL").T)

    if highlight_in_bold:
        done_per_day["success"] = done_per_day["success"].map(make_bold)
        done_per_day.loc["TOTAL"] = done_per_day.loc["TOTAL"].map(make_bold)

    table_html = done_per_day.to_string()
    # logger.info(f"{[a for a in dir(update.message) if a.startswith('reply')]}")

    wanted_items = filter_wanted_items()
    nwanted_item = len(wanted_items)
    nwanted_item_msg = f"{nwanted_item=:,}"
    done_per_day_msg = f"<pre>{table_html} \n\n{nwanted_item_msg}</pre>"
    # logger.info(f"{done_per_day_msg=}")
    update.message.reply_html(done_per_day_msg)
    # update.message.reply_html(nwanted_item_msg)


##########################
####    general handlers
##########################


def text(update, context):
    """General method that responds to user text input.

    parses a goodreads title
    """
    global STATE, STATE_CONTEXT
    msg = "You can talk to me directly, but you have to pass a message that contains a valid goodreads url"

    # logger.info(f" \n{dir(context)=} \n{dir(update.message)=} \n{update.message.text=}")
    # msg += debug_msg
    # msg = debug_msg

    # try finding 'http://...' in msg text
    logger.debug(f"{update.message.text=}")

    if STATE == State.DEFAULT:
        msg = match_push_book(update.message.text) or msg

    # handle user input for zlib download_item to add to wanted items
    elif STATE == State.PARSE_ZLIB_TO_DOWNLOAD:
        msg = f"should parse zlib to download item"
        try:
            df = STATE_CONTEXT["df"]
            book = STATE_CONTEXT["book"]

            assert not df.empty

            if update.message.text.lower() == "all":
                ix = slice(None)

            # int ix was (probably) passed
            else:
                ix = int(update.message.text)
                assert ix in df.index, f"{ix=}, {type(ix)=}, {df.index=}"
                ix = pd.IndexSlice[
                    ix:ix
                ]  # conver to indexslice, so the view will always be of type dataframe

            msg = f"selected {ix=}"
            sel_items = df.loc[ix]

            responses = []
            # send wanted request for every selected row
            for row in sel_items.to_dict("records"):
                reqBody = {
                    "content": row
                    | {
                        "book_id": book["id"],
                        "how": "personal",
                        "id": str(uuid.uuid4()),
                    }
                }
                # reqBody = {"content": {"book_id": book["id"], "fileType": row["fileType"], "url": row['url'], "how": "personal"}}
                logger.info(f"{reqBody=}")
                jsondata = json.dumps(reqBody)
                reqdata = jsondata.encode("utf-8")

                # todo: move api host to settings file
                url = f"http://{API_HOST}:8000/api/add_wanted_list"
                request = Request(url, data=reqdata)
                with urlopen(request) as conn:
                    res = conn.read().decode()

                responses.append(res)
                json_res = json.loads(res)

                logger.info(f"{json_res=}")

            msg += "\n\n".join([""] + responses)

        except Exception as e:
            logger.error(
                f"could not parse item index from dataframe: {e=!r} \ntraceback={traceback.format_exc()}"
            )
        finally:
            STATE, STATE_CONTEXT = resetState()

    else:
        msg = "invalid state was passed"
        logger.error(msg)

    return update.message.reply_html(msg)


def file_handler(update, context, sleep_ms=100):
    """Deal with user-send files, csv or json for a list of goodreads titles to scrape."""
    # file = context.bot.get_file(update.message.document).download()

    # logger.info(f"{dir(context.bot)=}")
    # logger.info(f"{type(file)=}")

    # writing to a custom file
    FILE = f"output/tmp"
    with open(FILE, "wb") as f:
        logger.info(
            f"dir file: \n\n {dir(context.bot.get_file(update.message.document))}"
        )
        logger.info(f"{context.bot.get_file(update.message.document).file_path=}")
        # return
        _ = context.bot.get_file(update.message.document).download(out=f)

    # check if file is csv or json
    # if not file.endswith(("json", "csv")):
    #     update.message.reply_text("please pass json or csv files only")
    #     return

    with open(FILE, "r", encoding="utf") as f:
        # logger.info(f"{dir(f)=}")
        # filename = FILE
        # if filename.endswith("json"):
        try:
            items_ = json.load(f)
        except Exception as e:
            log_and_reply(update, f"cannot read json file. {e=!r}")
            return

        logger.info(f"{items_=}")

        if not isinstance(items_, list):
            log_and_reply(update, "please send me valid json file")
            return

        if not isinstance(items_[0], str):
            log_and_reply(
                update, "please pass me json names of book titles, as plain strings"
            )
            return

        # elif filename.endswith("csv"):
        #     raise NotImplementedError

        # else:
        #     log_and_reply(update, "please pass json or csv files only")
        #     return

    log_and_reply(update, "got a file")

    # push all books
    for item in items_:
        msg = match_push_book(item)
        log_and_reply(update, msg, "html")
        sleep(sleep_ms / 1_000)


def add_handlers():
    # add command handlers for different command
    dp.add_handler(CommandHandler("start", start))
    dp.add_handler(CommandHandler("parse", parse))
    dp.add_handler(CommandHandler("add", add))
    dp.add_handler(CommandHandler("addw", addw))
    dp.add_handler(CommandHandler("items", items))
    dp.add_handler(CommandHandler("scrape", scrape))
    dp.add_handler(CommandHandler("to_postgres", to_postgres))
    dp.add_handler(CommandHandler("clear", clear))
    dp.add_handler(CommandHandler("lastn", lastn))
    dp.add_handler(CommandHandler("status", status))

    dp.add_handler(
        CommandHandler("help", help_)
    )  # how to pass all added handlers to help message?

    # add an handler for normal text (not commands)
    dp.add_handler(MessageHandler(Filters.text, text))
    # add file handler
    dp.add_handler(MessageHandler(Filters.document, file_handler))

    # error logging
    dp.add_error_handler(error)


# to start the bot
def main():
    # start the bot
    updater.start_polling()
    # set the bot to run until you force it to stop
    updater.idle()


class ArgParser:
    """create CLI parser"""

    @staticmethod
    def create_parser():
        return argparse.ArgumentParser()

    @classmethod
    def get_parser(cls):

        CLI = cls.create_parser()

        CLI.add_argument(
            "-v",
            "--verbosity",
            type=str,
            default="info",
            help=f"choose debug log level: {', '.join(loggingLevelNames())}",
        )
        CLI.add_argument(
            "-l",
            "--local",
            action="store_true",
            help="connecting to local or global mysql server. make sure --network=host is enabled for the container",
        )
        CLI.add_argument(
            "--dryrun",
            action="store_true",
            default=False,
            help="Only load browser and login, do nothing else",
        )

        return CLI


if __name__ == "__main__":

    parser = ArgParser.get_parser()
    args = parser.parse_args()

    add_handlers()

    if not args.dryrun:
        main()
