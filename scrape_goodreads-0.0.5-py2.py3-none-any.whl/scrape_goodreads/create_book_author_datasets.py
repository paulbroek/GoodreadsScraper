"""create_book_author_datasets.py.

get all books from postgres, and save as feather file

Run:
    ipy create_book_author_datasets.py -i -- -s
    
    # only load previously saved dataset
    ipy create_book_author_datasets.py -i -- -l
"""

import argparse

import pandas as pd
from rarc_utils.sqlalchemy_base import fmt_connection_url
from scrape_goodreads.models import psql
from scrape_goodreads.settings import ALL_BOOKS_PATH, MY_DOWNLOADS_PATH

con_url = fmt_connection_url(psql)


def create_all_books_dataset(con) -> pd.DataFrame:
    """Get dataset directly from materialized view."""
    query = """
        REFRESH MATERIALIZED VIEW all_books;
        SELECT * FROM all_books;
    """

    df: pd.DataFrame = pd.read_sql(query, con)
    return df


def create_my_downloads_dataset(con) -> pd.DataFrame:
    """Get dataset directly from materialized view."""
    query = """ 
            REFRESH MATERIALIZED VIEW vw_last_downloads;
            REFRESH MATERIALIZED VIEW vw_genres_of_downloads;
            SELECT * FROM vw_genres_of_downloads;"""

    df: pd.DataFrame = pd.read_sql(query, con)
    df["genres"] = df["genres_arr"].map(", ".join)
    return df


parser = argparse.ArgumentParser(
    description="create_book_author_datasets optional parameters"
)
parser.add_argument(
    "-l",
    "--load_dataset",
    action="store_true",
    default=False,
    help="Load feather dataset",
)
parser.add_argument(
    "-s",
    "--save_dataset",
    action="store_true",
    default=False,
    help="Save feather dataset",
)

if __name__ == "__main__":
    args = parser.parse_args()

    create_dataset = True

    if args.load_dataset:
        dataset = pd.read_feather(ALL_BOOKS_PATH)
        my_downloads = pd.read_feather(MY_DOWNLOADS_PATH)
        create_dataset = False

    if create_dataset:
        dataset = create_all_books_dataset(con_url)
        my_downloads = create_my_downloads_dataset(con_url)

    if create_dataset and args.save_dataset:
        dataset.to_feather(ALL_BOOKS_PATH)
        my_downloads.to_feather(MY_DOWNLOADS_PATH)
