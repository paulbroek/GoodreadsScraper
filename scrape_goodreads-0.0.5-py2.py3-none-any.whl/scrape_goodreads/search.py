""" google search utility methods

    google search will limit your requests,
    so if you want to scrape let's say more than 100 items per hour, use a container setup
    instructions:   https://juanluisrto.medium.com/scraping-google-search-without-getting-caught-e43bb91b363e
    repo:           https://github.com/juanluisrto/Scraping-orchestra

    which I forked: https://github.com/paulbroek/google-search-orchestra
"""

import asyncio
import logging
import re
from pathlib import Path
from time import sleep
from typing import Optional

import numpy as np
import pandas as pd
from googlesearch import search
from scrape_zlib import word_similarity
from tqdm import tqdm

try:
    from .models import (
        psql,
        get_session,
        Book,
        DownloadItem,
        DownloadItemType,
        get_str_mappings,
    )
except ImportError:
    from models import (
        psql,
        get_session,
        Book,
        DownloadItem,
        DownloadItemType,
        get_str_mappings,
    )

goodreads_url = "https://www.goodreads.com/book/show/"
goodreadsUrlRegex = re.compile(r"(.+show/)(.+)")
proxy = None
# proxy = 'socks5h://localhost:9150' # make sure tor is running on port 9150

logger = logging.getLogger(__name__)

# df_files = load_gdrive_txt('gdrive_books.txt')
# df_book = get_all(s, Book, to='pandas', unpackMethod='__dict__')
# df_book['author_name'] = df_book.author.map(lambda x: x.name)
# df_book['author_title'] = df_book[['title','author_name']].agg(' - '.join, axis=1)
def load_gdrive_txt(
    file: str = None, replaceDir=True, replacePostfix=True
) -> pd.DataFrame:
    """load a list of existing ebooks in google drive to list or dataframe"""

    df_files = pd.read_csv(file, names=["title"], delimiter="\t")
    if replaceDir:
        df_files["path"] = df_files["title"]
        df_files["title"] = df_files.title.str.replace("/home/paul/gdrive/Books/", "")
        # also remove any subdir, like 'Yoga/' or 'Computer Science/'
        df_files["title"] = df_files.title.str.replace(r".+/", "")

    # remove (z-lib.org).pdf and (z-lib.org).epub
    if replacePostfix:
        df_files["title"] = df_files.title.str.replace(r"\(z-lib.org\)", "")
        df_files["title"] = df_files.title.str.replace(r"(.pdf|.epub)", "")

    # set id index for easier selection later
    df_files.index = df_files.title

    return df_files


def match_book_title(
    book_title: str, df_book: pd.DataFrame, limit: int = None
) -> pd.DataFrame:

    assert "author_title" in df_book.columns
    df_book = df_book.copy()
    df_book["match"] = df_book.author_title.map(
        lambda x: word_similarity(x, book_title)
    )

    sorted_res = df_book.sort_values("match", ascending=False)
    if limit is not None:
        return sorted_res.head(limit)

    return sorted_res


# res = match_existing_books_with_postgres(df_book, df_files, match_threshold=65)
# res[['author_title','title','match_pct']].head(20)
def match_existing_books_with_postgres(
    df_book, df_files, match_threshold=65
) -> pd.DataFrame:
    """Match a list of book titles with existing titles in postgres.

    so they can be registered as download_item(pdf | epub)
    and removed from 'wanted' list in redis

    match_threshold     items that have a match percentage lower than this thres, will ask for manual confirmation
    """
    df_res = df_files.copy()
    df_res["match_book_id"] = np.nan
    df_res["match_author_title"] = np.nan
    df_res["match_pct"] = np.nan

    book_titles = df_files.title.values

    for book_title in tqdm(book_titles, mininterval=1):
        match_res = match_book_title(book_title, df_book, limit=10)
        best_match = match_res.iloc[0]
        if best_match.match >= match_threshold:
            df_res.loc[book_title, "match_pct"] = best_match.match
            df_res.loc[book_title, "author_title"] = best_match.author_title
            df_res.loc[book_title, "match_book_id"] = best_match.id
            # todo: save book dictionary

    nmatch = np.sum(~np.isnan(df_res["match_book_id"]))
    logger.info(f"found {nmatch} matches for {len(df_files)} book titles")

    return df_res.sort_values("match_pct", ascending=False)


def google_search_book_title(
    book_title: str = None, pfx="goodreads", res=None, sleepSec=0.6
) -> Optional[str]:
    """Search google for goodreads book title.

    returns best match that contains 'goodreads'

    example:
        google_search_book_title('tony robbins awaken power within')
        returns: '180116.Awaken_the_Giant_Within'

    You get blocked if you query Search too often. Best way to circumvent this,
    is change your IP through new container
    initialization, or through TOR. Article below explains a container setup:
        https://juanluisrto.medium.com/scraping-google-search-without-getting-caught-e43bb91b363e
    """
    if res is None:
        # assert query is not None
        query = f"{pfx} {book_title}"
        res = search(query)

        sleep(sleepSec)  # never over request google, or you get banned many hours

    filteredRes = [r for r in res if "goodreads" in r]
    if len(filteredRes) > 0:
        re_res = goodreadsUrlRegex.search(filteredRes[0])
        if re_res is not None:
            # group1 is the prefix url, group2 is the book_title id
            return re_res.group(2)

    return


# df_files2 = google_search_book_titles(df_files.head(10))
# df_files2 = google_search_book_titles(df_files)
# df_files = pd.DataFrame({"titles": [1, 2]})
# df_files2['goodreads_title_match'].isnull().sum() / len(df_files2)
def google_search_book_titles(
    df: pd.DataFrame, pfx="goodreads", delay_ms=500, tmp=None
):

    df = df.copy()

    # functional approach, but when http request fails, no rows are written
    # df['goodreads_title_match'] = df.title.map(lambda x: google_search_book_title(x, pfx=pfx))

    # imperative approach
    if "goodreads_title_match" not in df.columns:
        df["goodreads_title_match"] = None

    for file in tqdm(df.index, mininterval=1):
        assert isinstance(
            file, str
        ), f"please pas index as strings. can use: df.set_index('title', inplace=True), to move title to index"
        search_res = google_search_book_title(file, pfx=pfx)

        if tmp is not None:
            assert isinstance(tmp, list)
            tmp.append(search_res)

        df.loc[file]["goodreads_title_match"] = search_res

        sleep(delay_ms / 1_000)

    return df


def load_many_search_result_csvs(csvDir="/tmp/csv/") -> pd.DataFrame:
    """Load results from google cloud App google-search-orchestra to pandas.

    https://github.com/paulbroek/google-search-orchestra

    first copy files from gcloud to local temp dir:
        gsutil -m cp gs://see-book-335222.appspot.com/csv/* /tmp/csv

    returns a dataframe with index book titles from disk, and a column of goodreads book ids:

                                                                      goodreads_title_match
        title
        The Road to learn React Your journey to master ...       37503118-the-road-to-react
        The Checklist Manifesto How to Get Things Right...  6667514-the-checklist-manifesto
        [Osho]_Courage__The_Joy_of_Living_Dangerously.csv                             96999
        [Jake_VanderPlas]_Python_Data_Science_Handbook_...                         26457146
    """
    csvPath = Path(csvDir)

    csvPaths = list(csvPath.iterdir())
    # path names without '/tmp/csv/..' prefix
    csvFiles = [p.name for p in csvPath.iterdir()]
    logger.info(f"found {len(csvFiles)} files")
    # create empty df with file name index
    df = pd.DataFrame(dict(query=csvFiles))
    # remove pfx 'goodreads' string from query to get book title on disk
    df["title"] = df["query"].str.replace(f"^goodreads ", "")
    titles = list(df.title.values)
    df.index = df.title
    df["goodreads_title_match"] = None
    del df["title"], df["query"]

    # load csv files, take first row if it succesfully regex matches a goodreads book show item
    for csvPath, title in tqdm(zip(csvPaths, titles), mininterval=1):
        df_res = pd.read_csv(csvPath, index_col=0)
        # print(f'df.head=\n{df.head(5)}')
        res = list(df_res.url.values)
        # passing a 'res', skips the scrape part, and only regex matches the book title (if present in search results)
        df.loc[title]["goodreads_title_match"] = google_search_book_title(res=res)

    df["url"] = goodreads_url + df["goodreads_title_match"]

    return df


# df = concat_matches_with_titles()
# df = concat_matches_with_titles(dropna=True)
def concat_matches_with_titles(s, dropna=False):
    """Load both goodreads id dataframe and a dataframe with pathnames (on google drive).

    concat the result into a new dataframe
    """
    # load matches
    fdf = pd.read_csv(
        "/home/paul/repos/misc-scraping/misc_scraping/scrape_goodreads/matches.csv"
    )
    fdf["title"] = fdf.title.str.replace(".csv", "")
    fdf.index = fdf["title"]
    del fdf["title"], fdf["Unnamed: 0"]

    # load files
    df_files = load_gdrive_txt("gdrive_books.txt")
    df_files = df_files[~df_files.index.duplicated(keep="first")]

    # join the datasets on index
    df = pd.concat([fdf, df_files], axis=1)

    # set the file type
    df["fileType"] = np.where(
        df["path"].str.endswith("epub"),
        "EPUB",
        np.where(df["path"].str.endswith("pdf"), "PDF", "no type"),
    )
    by_type = df.groupby("fileType")["fileType"].count()
    logger.info(f"grouped by fileType: \n{by_type}")

    # get books from postgres (if it exists)
    df["book"] = df["goodreads_title_match"].map(
        lambda x: s.query(Book).filter_by(url=f"{goodreads_url}{x}").first()
    )
    df["book_id"] = df["book"].map(lambda x: x.id if x is not None else None)

    nbook_missing = df["book_id"].isnull().sum()
    logger.warning(f"{nbook_missing=} books missing")

    if dropna:
        logger.warning(f"dropping {nbook_missing} rows")
        df = df[~df["book_id"].isnull()]
        df["book_id"] = df["book_id"].astype("int")

    return df


# df_ = create_download_items_from_df(df, df_resp, commit=False)
def create_download_items_from_df(df_hdd, df_resp, s, commit=False):
    """follows after 'concat_matches_with_titles'
    creates and commits download items with done=True for every item
    """

    str_mappings = get_str_mappings(s, (DownloadItemType,))

    df_hdd = df_hdd.copy()

    # merge hdd books with zlib search results on multiindex (book_id, fileType)
    df_hdd.index = pd.MultiIndex.from_frame(df_hdd[["book_id", "fileType"]])
    df = pd.merge(df_hdd, df_resp, left_index=True, right_index=True)
    df["location"] = df["path"].str.replace(
        r"([^\/]+$)", ""
    )  # get path before last '/'
    df["server_location"] = df["location"].str.replace("/home/paul", "")
    df["file_name"] = df.apply(lambda x: x["path"].replace(x["location"], ""), axis=1)

    # df_[['location','server_location','path','file_name']]
    iType = str_mappings["download_item_type"]

    # todo: finish 12-17

    # first create download_items ! by running 'add_wanted_list' post endpoint

    # look up download_item in postgres

    # ...
    # s.query(DownloadItem).filter_by(book_id=b.id)

    df["di"] = df.apply(
        lambda row: DownloadItem(
            book=row["book"],
            zlib_name=row["best_match"]["title"],
            zlib_authors=row["best_match"]["authors"],
            file_name=row["file_name"],
            location=row["server_location"],
            file_type=iType[row["fileType"]],
            dummy=False,
            pct_done=100,
            done=True,
        ),
        axis=1,
    )

    if commit:
        logger.info("commiting download_items..")
        for di in tqdm(df["di"].values, mininterval=1):
            s.add(di)

        s.commit()  # downside of this approach is that failed attempts also get added to postgres

    return df


def hdd_books_to_postgres_workflow(commit=False):

    try:
        from .process_data import (
            postgres_to_queries,
            request_zlib_for_many_titles,
            zlib_queries_to_pandas,
        )
    except ImportError:
        from process_data import (
            postgres_to_queries,
            request_zlib_for_many_titles,
            zlib_queries_to_pandas,
        )

    queries2 = postgres_to_queries(1000)
    responses = asyncio.run(request_zlib_for_many_titles(queries2, limit_per_host=100))
    df_resp = zlib_queries_to_pandas(responses)
    s = get_session(psql)()
    df = concat_matches_with_titles(s, dropna=True)
    df_ = create_download_items_from_df(df, df_resp, s, commit=commit)
    # should commit to postgres..
