"""update_author_to_scrape.py.

Update all AuthorToScrape items in db with recent Author data in database
"""

import argparse
import logging

import pandas as pd
from rarc_utils.log import setup_logger
from rarc_utils.sqlalchemy_base import get_session
from scrape_goodreads.models import Author, AuthorToScrape, psql
from sqlalchemy import select

log_fmt = "%(asctime)s - %(module)-16s - %(lineno)-4s - %(funcName)-20s - %(levelname)-7s - %(message)s"  # name
logger = setup_logger(
    cmdLevel=logging.INFO, saveFile=0, savePandas=1, color=1, fmt=log_fmt
)

s = get_session(psql)()

logger.info(f"fetching author_to_scrapes")
to_scrapes = s.execute(select(AuthorToScrape)).scalars().fetchall()
logger.info(f"got {to_scrapes:,} toauthor_to_scrapes")
logger.info(f"fetching authors")
authors = s.execute(select(Author)).scalars().fetchall()
logger.info(f"got {authors:,} authors")
author_df = pd.DataFrame([a.as_dict() for a in authors])
author_df["greads_id"] = author_df["url"].str.split("show/").map(lambda x: x[-1])
id_to_scrape = {i.id: i for i in to_scrapes}
author_id_to_updated = dict(zip(*author_df[["greads_id","updated"]].values.T))

# now you can update author_to_scrape items
nmissing = 0
for author_id, updated in author_id_to_updated.items():
    a = id_to_scrape.get(author_id, None)
    if a is not None:
        a.last_scraped = updated
    else:
        nmissing += 1

logger.warning(f"{nmissing=:,}")

# slow
s.commit()
