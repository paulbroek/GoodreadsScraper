"""get_authors_from_sitemap.py.

Usage:
    ipy get_authors_from_sitemap.py -i -- -s

    # load previously saved items
    ipy get_authors_from_sitemap.py -i -- -l

    # push to database
    ipy get_authors_from_sitemap.py -i -- -lp
"""

import argparse
import asyncio
import gzip
from typing import Dict, List, Set
from urllib import request

import pandas as pd
import requests  # type: ignore[import]
from bs4 import BeautifulSoup  # type: ignore[import]
from rarc_utils.sqlalchemy_base import (create_many, get_async_session,
                                        get_session)
from scrape_goodreads.models import AuthorToScrape, psql
from scrape_goodreads.settings import ALL_AUTHOR_ID_PATH
from tqdm import tqdm  # type: ignore[import]

URL = "https://www.goodreads.com/siteindex.author.xml"
psql_session = get_session(psql)()
async_session = get_async_session(psql)


def extract_sitemap(url: str) -> List[str]:
    xmlDict = {}

    r = requests.get(url)
    xml = r.text

    soup = BeautifulSoup(xml)
    sitemapTags = soup.find_all("sitemap")

    print("The number of sitemaps are {0}".format(len(sitemapTags)))

    for sitemap in sitemapTags:
        xmlDict[sitemap.findNext("loc").text] = sitemap.findNext("lastmod").text

    authors: Set[str] = set()

    # extract author urls
    for u in tqdm(xmlDict.keys()):

        with request.urlopen(u) as response:
            out = gzip.decompress(response.read())
            sitemapSoup = BeautifulSoup(out)

            urls = sitemapSoup.find_all("loc")

            for url_ in urls:
                authors.add(url_.text)

            print(f"{len(authors)=:,}")

    return list(authors)


def authors_to_scrape_to_postgres(items: Dict[str, dict], **kwargs):
    async def run():
        async with async_session() as session:
            await create_many(session, AuthorToScrape, items, nameAttr="id", **kwargs)

    asyncio.run(run())


parser = argparse.ArgumentParser(
    description="get_authors_from_sitemap optional parameters"
)
parser.add_argument(
    "-l",
    "--load",
    action="store_true",
    default=False,
    help="Load author ids from feather",
)
parser.add_argument(
    "-s",
    "--save",
    action="store_true",
    default=False,
    help=f"Save author ids to feather \n{ALL_AUTHOR_ID_PATH.as_posix()}",
)
parser.add_argument(
    "-p",
    "--push",
    action="store_true",
    default=False,
    help="push AuthorToScrape items to db",
)

if __name__ == "__main__":
    args = parser.parse_args()

    if args.load:
        df = pd.read_feather(ALL_AUTHOR_ID_PATH)
        # all_authors = df["id"].to_list()

    else:
        all_authors = extract_sitemap(URL)

    if not args.load and args.save:
        df = pd.DataFrame(dict(url=all_authors))
        df["id"] = df.url.str.split("show/").map(lambda x: x[-1])
        del df["url"]
        df.to_feather(ALL_AUTHOR_ID_PATH)

    if args.push:
        authors = {a: AuthorToScrape(id=a, npage=3) for a in df.id[50_000:]}
        authors_to_scrape_to_postgres(authors, autobulk=True)
