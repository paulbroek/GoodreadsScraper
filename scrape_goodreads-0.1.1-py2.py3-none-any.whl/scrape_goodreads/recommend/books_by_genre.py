"""books_by_genre.py.

extract genres from books you have downloaded so far,
combine that data with all books that can be downloaded, and distill a list with overlap between the too
in short: what are the next list of books to be downloaded, with overlap to your fields of interest

Run:
    cd /home/paul/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/recommend
    ipy books_by_genre.py -i -- -r
    ipy books_by_genre.py -i --
"""

import argparse
import logging

import matplotlib.pyplot as plt
import pandas as pd
import pylab
import seaborn as sns
from rarc_utils.log import setup_logger
from rarc_utils.sqlalchemy_base import get_session
from scrape_goodreads.models import psql
from scrape_goodreads.recommend.methods import (compute_genre_counts,
                                                parse_my_downloads)

# from youtube_recommender.io_methods import io_methods as im

log_fmt = "%(asctime)s - %(module)-16s - %(lineno)-4s - %(funcName)-20s - %(levelname)-7s - %(message)s"
logger = setup_logger(
    cmdLevel=logging.INFO, saveFile=0, savePandas=1, color=1, fmt=log_fmt
)

s = get_session(psql)()

def plot_dist(x):
    sns.set(rc={"figure.figsize": (8, 4)})
    # np.random.seed(0)
    # x = np.random.randn(100)
    # ax = sns.distplot(x)
    ax = sns.histplot(data=x)
    plt.show()

parser = argparse.ArgumentParser(
    description="recomend_books_by_genre optional parameters"
)
parser.add_argument(
    "-r",
    "--refresh_views",
    action="store_true",
    default=False,
    help="Refresh materialized views before fetching data",
)

parser.add_argument(
    "-s",
    "--save_feather",
    action="store_true",
    default=False,
    help="Save dataset to feather",
)

if __name__ == "__main__":
    args = parser.parse_args()

    if args.refresh_views:
        s.execute("REFRESH MATERIALIZED VIEW all_books;")
        s.execute("REFRESH MATERIALIZED VIEW vw_last_downloads;")
        s.execute("REFRESH MATERIALIZED VIEW vw_genres_of_downloads;")

    all_books_query = """
        SELECT * FROM all_books;
    """

    # all_books_query = """
    #     SELECT
    #         author_id,
    #         author_name,
    #         avg_rating,
    #         genres,
    #         genres_agg,
    #         id,
    #         ngenre,
    #         num_pages,
    #         num_num_ratings,
    #         num_reviews,
    #         title

    #     FROM all_books;
    # """

    all_books = s.execute(all_books_query).mappings().fetchall()
    df = pd.DataFrame(all_books)

    my_downloads_query = """
        SELECT * FROM vw_genres_of_downloads;
    """

    my_downloads = s.execute(my_downloads_query).mappings().fetchall()
    my_downloads_df = parse_my_downloads(my_downloads, df)
    genre_counts = compute_genre_counts(my_downloads_df)
    # genre_counts.head(30)

    # todo: think of a way to predict the next optimal to_download item. should have overlap with top genre_counts AND a high rating / num_reviews

    # todo: extract specific topics from those books. use description? titles? epub files?
    # this is not easy

    # save to feather
    # if args.save_feather:
    #     im.save_feather(df, EDUCATIONAL_VIDEOS_PATH, "educational_video")
