"""topic_modeling_bertopic.py.

Extract topic from book descriptions using BERTopic

Run:
    conda activate py39
    cd ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/recommend

    # create datasets first?
    ipy ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/create_book_author_datasets.py -i -- -s

    # or rsync a dataset
    rsync -avz --progress  ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/data/* -e "ssh -p 5689" paul@192.168.178.46:~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/data
    rsync -avz --progress  -e "ssh -p 5689" paul@192.168.178.46:/home/paul/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/data ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads

    # train model and save model, topics and probs to feather
    ipy topic_modeling_bertopic.py -i -- -s

    # load existing model, topics and probs
    ipy topic_modeling_bertopic.py -i -- -l
"""

import argparse
import logging
import sys

import pandas as pd
from bertopic import BERTopic  # type: ignore[import]
from rarc_utils.log import setup_logger
from scrape_goodreads.recommend.methods import compute_genre_counts
from scrape_goodreads.settings import (ALL_BOOKS_PATH, MODEL_PATH,
                                       MY_DOWNLOADS_PATH, TOPICS_PATH)
from youtube_recommender.io_methods import io_methods as im  # type: ignore[import]
from youtube_recommender.topic_modeling.methods import (similar_topics_to_word,
                                                        topic_presence_by)

log_fmt = "%(asctime)s - %(module)-16s - %(lineno)-4s - %(funcName)-20s - %(levelname)-7s - %(message)s"  # name
logger = setup_logger(
    cmdLevel=logging.INFO, saveFile=0, savePandas=1, color=1, fmt=log_fmt
)


def data_pipeline(
    df: pd.DataFrame,
    truncateLen=1_200,
    dropLonger=False,
    dismissGenres=(
        "Fiction",
        "Fantasy",
        "Romance",
        "Sequential Art",
        "Comics",
        "Manga",
        "Religion",
        "Graphic Novels",
        "Childrens",
        "Young Adult",
        "Adventure",
    ),
) -> pd.DataFrame:
    """Remove missing descriptions, keep english, truncate and/or dismiss long descriptions."""
    nrow_before = len(df)
    df = (
        df.dropna(subset=["description"])
        .rename(columns={"description": "description_full"})
        .copy()
    )
    df = df[df.language == "English"]

    # only keep books that have specific genres
    pat = "|".join(dismissGenres)
    df = df[~(df.genres.str.contains(pat) | False)]

    df["deslen"] = df["description_full"].map(len)
    df["description"] = df["description_full"].str.slice(0, truncateLen)

    if dropLonger:
        df = df[df.deslen <= truncateLen]

    logger.info(f"keeping {len(df):,} rows of {nrow_before:,}")

    return df


parser = argparse.ArgumentParser(
    description="topic_modeling_bertopic optional parameters"
)
parser.add_argument(
    "-l",
    "--load_model",
    action="store_true",
    default=False,
    help="Load bertopic model, topics and probabilities",
)
parser.add_argument(
    "-s",
    "--save_model",
    action="store_true",
    default=False,
    help="Save bertopic model, topics and probabilities",
)

parser.add_argument(
    "--dryrun",
    action="store_true",
    default=False,
    help="Only load datasets",
)

if __name__ == "__main__":
    args = parser.parse_args()

    all_data = pd.read_feather(ALL_BOOKS_PATH)

    data = data_pipeline(all_data, dropLonger=True)
    docs = data["description"].str.strip().to_list()
    doc_to_author_id = dict(zip(*data[["description", "author_id"]].values.T))
    doc_to_author_name = dict(zip(*data[["description", "author_name"]].values.T))

    my_downloads_df = pd.read_feather(MY_DOWNLOADS_PATH)
    genre_counts = compute_genre_counts(my_downloads_df)

    if args.dryrun:
        sys.exit()

    if args.load_model:
        topic_model = BERTopic.load(MODEL_PATH)
        topics, probs = im.load_topics(TOPICS_PATH)
    else:
        topic_model = BERTopic()
        topics, probs = topic_model.fit_transform(docs)

    # inspect a topic
    # topic_model.get_topic(0)

    # show topics with probabilities in dataframe
    info: pd.DataFrame = (
        topic_model.get_topic_info()[1:].sort_values("Topic").reset_index(drop=True)
    )
    assert info.Topic.is_monotonic_increasing
    logger.info(
        f"this model uses {len(info):,} topics, derived from {len(docs):,} documents"
    )

    most_similar = similar_topics_to_word(topic_model, info, "cloud", top_n=5)

    # extract the author names that cover certain topics most
    presence_by_author = topic_presence_by(
        topic_model, info, doc_to_author_name, by="author"
    )
    # doc_to_author_id

    if args.save_model and not args.load_model:
        topic_model.save(MODEL_PATH)
        im.save_topics(topics, probs, TOPICS_PATH)
