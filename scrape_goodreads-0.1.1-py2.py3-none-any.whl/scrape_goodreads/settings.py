"""Settings.py, general settings for scrape_goodreads."""

from pathlib import Path
from typing import Final

######################
##### cfg paths ######
######################

ENV_FILE: Final[str] = "/home/paul/repos/misc-scraping/misc_scraping//scrape_goodreads/config/.test.env"
CONFIG_FILE_NAME: Final[str] = "SCRAPE_GOODREADS_CONFIG_FILE"

######################
##### File paths #####
######################

REPO_DIR: Final[Path] = Path(
    "/home/paul/repos/misc-scraping/misc_scraping/scrape_goodreads/"
)
DATA_DIR: Final[Path] = REPO_DIR / "data"

TOP_AUTHORS_PATH: Final[Path] = DATA_DIR / "top_authors.feather"
BOOKS_PATH: Final[Path] = DATA_DIR / "books.feather"
AUTHORS_PATH: Final[Path] = DATA_DIR / "authors.feather"
ALL_BOOKS_PATH: Final[Path] = DATA_DIR / "all_books.feather"
MY_DOWNLOADS_PATH: Final[Path] = DATA_DIR / "my_downloads.feather"

ALL_AUTHOR_ID_PATH: Final[Path] = DATA_DIR / "all_authors.feather"

MODEL_PATH: Final[Path] = DATA_DIR / "book_descriptions.model"
TOPICS_PATH: Final[Path] = DATA_DIR / "book_descriptions.feather"

GOODREADS_PFX: Final[str] = "https://www.goodreads.com"
