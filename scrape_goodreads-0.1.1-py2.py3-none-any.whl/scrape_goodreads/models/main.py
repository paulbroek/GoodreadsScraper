"""
    based on:
         https://docs.sqlalchemy.org/en/14/orm/extensions/asyncio.html

    create database 'trade' in psql (command line tool for postgres):
        (go inside psql) docker exec -it postgres-goodreads-master bash -c 'psql -U postgres -W'   ENTER PASSWORD, see yml file

        CREATE DATABASE "goodreads";

    now connect using:
        docker exec -it postgres-goodreads-master bash -c 'psql trade -U postgres -W'

    or directly, by installing postgres on linux (sudo apt-get -y install postgresql):
        pgcli -h 81.169.252.73 -p 5438 -u postgres goodreads
        psql -h 81.169.252.73 -d goodreads -U postgres -W
        psql -h 81.169.252.73 -d goodreads -U postgres (when using a password file: echo "77.249.149.174:5432:trade:postgres:PASSWORD" > ~/.pgpass   Don't forget to set permissions: chmod 600 ~/.pgpass)

    create some tables using (from ./rarc/rarc directory):
        ipy ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/scripts/create_models.py -i -- --create 1

    list data:
        ipy ~/repos/misc-scraping/misc_scraping/scrape_goodreads/scrape_goodreads/scripts/create_models.py -i -- --create 0

    Create views in psql (for easy querying later):

        docker exec -it postgres-goodreads-master bash -c 'psql goodreads -U postgres -f /greads_data/views.sql'

    Create triggers in psql, so that most views are automatically refreshed for incoming records:

        docker exec -it postgres-goodreads-master bash -c 'psql goodreads -U postgres -f /greads_data/triggers.sql'

    Refresh a view:

        REFRESH MATERIALIZED VIEW vw_books;
        REFRESH MATERIALIZED VIEW vw_books_with_downloads;

    Show some books in psql:

        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language
        FROM        vw_books
        LIMIT       5;

    Show only books with nonzero cover_image url:

        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language, trunc_cover_image
        FROM        vw_books
        WHERE       cover_image is NOT NULL
        LIMIT       5;

    Show recently added books:

        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language, updated, trunc_cover_image
        FROM        vw_books
        ORDER BY    updated DESC
        LIMIT       5;

    Show recently downloaded books:

        SELECT      trunc_title, author_name, avg_rating, num_reviews, num_ratings, num_pages, language, updated, ndownload, trunc_cover_image
        FROM        vw_books_with_downloads
        ORDER BY    updated DESC
        LIMIT       5;

    Show recent download_items:

        REFRESH MATERIALIZED VIEW vw_last_downloads;

        SELECT      *, date_trunc('seconds', NOW() - updated) AS updated_ago
        FROM        vw_last_downloads
        WHERE       done = 't'
        LIMIT       15;

    Get only genre=='Science' books:

        SELECT book.title, genre.name AS genre_name
        FROM book_genre_association bga
        INNER JOIN book ON bga.book_id = book.id
        INNER JOIN genre ON bga.genre_id = genre.id
        WHERE genre.name = 'Science'
        LIMIT 10;

    Or all book data for one genre, easier for node API usage:

        SELECT book.*, author.name AS author_name, genre.name AS genre_name
        FROM book_genre_association bga
        INNER JOIN book ON bga.book_id = book.id
        INNER JOIN genre ON bga.genre_id = genre.id
        INNER JOIN author ON author.id = book.author_id
        WHERE genre.name = 'Science'
        LIMIT 10;

    Most used query: get all books and concatenate genres into a comma separated string (so react can filter on multiple genres per book)

        SELECT book.*, author.name AS author_name, string_agg(genre.name, ',') as genres
        FROM book_genre_association bga
        INNER JOIN book ON bga.book_id = book.id
        LEFT JOIN genre ON bga.genre_id = genre.id
        INNER JOIN author ON author.id = book.author_id
        GROUP BY book.id, author.id
        ORDER BY
        LIMIT 10;

    Get popular book categories currently in database:

        SELECT genre.name, COUNT(DISTINCT genre.name) as genre_count
        FROM book_genre_association bga
        INNER JOIN genre
        ON bga.genre_id = genre.id
        GROUP BY genre.name
        ORDER BY genre_count DESC
        LIMIT 10;

    For migrations use alembic. First install `pip install psycopg2-binary` and `pip install alembic` in current conda environment. Run `alembic init alembic`  in this folder,
    and update "alembic.ini" by changing sqlalchemy.url to `postgresql://postgres:mongo1991@77.249.149.174/goodreads`
        - update the env.py file by importing your model:
            from models import Base
            target_metadata = Base.metadata

        - Change something in the model below, and run
            alembic revision --autogenerate -m "Add sum_amount column for Position"    for example
            Check the contents of the new alembic/versions/****Add_sum... file and if it correct run:

        - `alembic upgrade head` to commit all changes

        - Excellent documentations on: https://alembic.sqlalchemy.org/en/latest/autogenerate.html

"""

from datetime import datetime
from typing import Any, Dict

from rarc_utils.sqlalchemy_base import (did_change, did_increase,
                                        did_increase_len,
                                        inject_str_attributes)
from sqlalchemy import (Boolean, Column, DateTime, Float, ForeignKey, Integer,
                        String, Text, UniqueConstraint, func)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from sqlalchemy.schema import Table

Base = declarative_base()

author_genre_association = Table('author_genre_association', Base.metadata,
    Column('author_id', Integer, ForeignKey('author.id')),
    Column('genre_id', Integer, ForeignKey('genre.id')), # an author can have multiple genres, a genre can belong to multiple authors
    UniqueConstraint('author_id', 'genre_id')
)

book_genre_association = Table('book_genre_association', Base.metadata,
    Column('book_id', Integer, ForeignKey('book.id')),
    Column('genre_id', Integer, ForeignKey('genre.id')), # a book can have multiple genres, a genre can belong to multiple books
    UniqueConstraint('book_id', 'genre_id')
)

book_character_association = Table('book_character_association', Base.metadata,
    Column('book_id', Integer, ForeignKey('book.id')),
    Column('character_id', Integer, ForeignKey('character.id')), # a book can have multiple characters, a character can belong to multiple books
    UniqueConstraint('book_id', 'character_id')
)

book_place_association = Table('book_place_association', Base.metadata,
    Column('book_id', Integer, ForeignKey('book.id')),
    Column('place_id', Integer, ForeignKey('place.id')), # a book can have multiple places, a place can belong to multiple books
    UniqueConstraint('book_id', 'place_id')
)

book_award_association = Table('book_award_association', Base.metadata,
    Column('book_id', Integer, ForeignKey('book.id')),
    Column('award_id', Integer, ForeignKey('award.id')), # a book can have multiple awards, a award can belong to multiple books
    UniqueConstraint('book_id', 'award_id')
)


# TODO: not being used as of january '23'
class ScrapeJob(Base):
    """ScrapeJob

    A scrapeJob is a request to scrape a book.
    It has statuses: requested, in_progress, sucess, failed
    """
    __tablename__ = "scrape_job"
    id          = Column(String, primary_key=True)

    url = Column(String)
    status = Column(String)
    source = Column(String)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "ScrapeJob(id={}, url={}, status={})".format(self.id, self.url, self.status)


class AuthorToScrape(Base):
    """AuthorToScrape

    An author Id fetched from sitemap https://www.goodreads.com/siteindex.author.xml (5M+ as of July 30 2022)
    This model is used for worker scrapers to see which author needs scraping
    """
    __tablename__ = "author_to_scrape"
    id          = Column(String, primary_key=True)
    last_scraped = Column(DateTime)
    nscrape     = Column(Integer, default=0, nullable=False)
    npage       = Column(Integer, nullable=False)
    lock        = Column(Boolean, default=False, nullable=False)

    nupdate = Column(Integer, default=0)
    # , onupdate=nupdate_count)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}
    # __table_args__ = (Index('index_updated', "updated", "is_open"), Index('index_created', "created", "is_open"))

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "AuthorToScrape(id={}, last_scraped={}, nscrape={}, npage={}, lock={})".format(self.id, self.last_scraped, self.nscrape, self.npage, self.lock)

class Author(Base):
    """ see https://github.com/havanagrawal/GoodreadsScraper
        for all fields that get scraped and can be used in the data model
    """
    __tablename__ = "author"
    id          = Column(Integer, primary_key=True)
    genres      = relationship("Genre", uselist=True, secondary=author_genre_association, lazy=True)
    url         = Column(String, nullable=False)
    name        = Column(String, nullable=False)
    birth_date  = Column(String, nullable=True)
    death_date  = Column(String, nullable=True)
    avg_rating  = Column(Float, nullable=True)
    num_reviews = Column(Integer, nullable=True)
    num_ratings = Column(Integer, nullable=True)
    about       = Column(String, nullable=True)

    nupdate = Column(Integer, default=0)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # title + author together should be unique for now
    UniqueConstraint('name', 'birth_date', name='unique_author')

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}
    # __table_args__ = (Index('index_updated', "updated", "is_open"), Index('index_created', "created", "is_open"))

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def json(self, popId=True):
        d = {c.name: getattr(self, c.name) for c in self.__table__.columns}
        d['created'] = d['created'].isoformat()
        d['updated'] = d['updated'].isoformat()

        if popId:
           d.pop('id')

        return d

    @staticmethod
    def from_json(item: dict, session):
        """Create model instance from json."""
        assert isinstance(item, dict)

        for dateField in ['created','updated']:
            if dateField in item and isinstance(item[dateField], str):
                item[dateField] = datetime.fromisoformat(item[dateField])

        instance = Author(**item)

        # write helper method for this functionality
        instance = inject_str_attributes(instance, item, Genre, session)
        # for genre in item.get('genres', []):
        #     genre = session.merge(Genre(name=genre))
        #     if hasattr(instance, 'genres'):
        #         instance.genres = [genre]
        #     else:
        #         instance.genres.append(genre)

        return instance

    def __repr__(self):
        return "Author(name={}, avg_rating={}, num_reviews={}, num_ratings={}, url={})".format(
            self.name,
            "{:.2f}".format(self.avg_rating) if self.avg_rating is not None else 'N/A',
            self.num_reviews if self.num_reviews is not None else 'N/A',
            self.num_ratings if self.num_ratings is not None else 'N/A',
            self.url,)

class Book(Base):
    """ see https://github.com/havanagrawal/GoodreadsScraper
        for all fields that get scraped and can be used in the data model
    """
    __tablename__ = "book"
    id                  = Column(Integer, primary_key=True)
    author_id           = Column(Integer, ForeignKey("author.id"))
    author              = relationship("Author", uselist=False, lazy='selectin')
    genres              = relationship("Genre", uselist=True, secondary=book_genre_association, lazy=True) #lazy='selectin') # lazy='joined') # , lazy='subquery')
    url                 = Column(String, nullable=False)
    cover_image         = Column(String, nullable=True)
    title               = Column(String, nullable=False)
    description         = Column(Text, nullable=True)
    avg_rating          = Column(Float, nullable=True)
    custom_rating       = Column(Float, nullable=True)
    num_reviews         = Column(Integer, nullable=True)
    num_ratings         = Column(Integer, nullable=True)
    num_pages           = Column(Integer, nullable=True)
    language            = Column(String, nullable=True)
    publish_date        = Column(String, nullable=True)
    original_publish_year = Column(Integer, nullable=True)
    characters          = relationship("Character", uselist=True, secondary=book_character_association, lazy=True)
    places              = relationship("Place", uselist=True, secondary=book_place_association, lazy=True)
    awards              = relationship("Award", uselist=True, secondary=book_award_association, lazy=True)
    isbn                = Column(String, nullable=True)
    isbn13              = Column(String, nullable=True)
    asin                = Column(String, nullable=True)
    series              = Column(String, nullable=True)
    rating_histogram    = relationship("RatingHistogram", uselist=False, backref="book")
    downloaded_items    = relationship("DownloadItem", uselist=True, back_populates='book', lazy='selectin')

    # title + author together should be unique for now
    UniqueConstraint('title', 'author_id', name='unique_title_author')

    nupdate = Column(Integer, default=0)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def json(self, popId=True):
        d = {c.name: getattr(self, c.name) for c in self.__table__.columns}
        d['created'] = d['created'].isoformat()
        d['updated'] = d['updated'].isoformat()

        if popId:
           d.pop('id')

        return d

    def as_big_dict(self):
        return {c: getattr(self, c) for c in dir(self) if not c.startswith(('_','__','registry'))}

    @staticmethod
    def from_json(item: dict, session):
        """Create model instance from json."""
        # TODO: should replace `book_from_dict` method in process_data.py

        assert isinstance(item, dict)
        # assert "author" in item or "author_id" in item
        assert isinstance(item["author"], dict)

        for dateField in ['created','updated']:
            if dateField in item and isinstance(item[dateField], str):
                item[dateField] = datetime.fromisoformat(item[dateField])

        # TODO: also get_or_create author
        # Create an instance of the Author class from the dictionary
        author_data = item.pop("author", None)
        if author_data:
            author = Author.query.filter_by(name=author_data["name"]).first()
            if author is None:
                author = Author(**author_data)
                session.add(author)
                session.flush()
            item["author_id"] = author.id
        elif "author_id" not in item:
            raise ValueError("Author must be provided")

        instance = Book(**item)

        instance = inject_str_attributes(instance, item, Character, session)
        instance = inject_str_attributes(instance, item, Genre, session)
        instance = inject_str_attributes(instance, item, Place, session)
        instance = inject_str_attributes(instance, item, Award, session)

        # TODO: replace author with author_id



        return instance

    def update_from_json(self, other: Dict[str, Any], skipCols=('id','created','updated','nupdate')) -> int:
        """Update object by overwriting fields from `other` object.

        Dismiss id, created and updated fields
        """
        nupdated = 0
        for attr in set(self.__table__.columns.keys()) - set(skipCols):
            newval = other.get(attr, None)
            if newval is not None:
                setattr(self, attr, newval)
                nupdated += 1

        return nupdated

    @staticmethod
    def did_change_diff(existing, new) -> Dict[str, bool]:
        """Return did_X per key.

        do not include `custom_rating` for now, since it is manually added
        not including it in a new item would overwrite it

        and: I cannot updated nested data yet, since it is not an attribute of the object, see
            `update_from_json` above
        """
        return {
            "description" : did_increase_len(existing, new, key="description"),
            "avg_rating": did_change(existing, new, key="avg_rating"),
            # "custom_rating": did_change(existing, new, key="custom_rating"),
            "num_reviews": did_increase(existing, new, key="num_reviews"),
            "num_ratings": did_increase(existing, new, key="num_ratings"),
            "num_pages": did_increase(existing, new, key="num_pages"),
            # "characters": did_increase_len(existing, new, key="characters"),
            # "places": did_increase_len(existing, new, key="places"),
        }

    @classmethod
    def did_change_pipeline(cls, existing, new) -> bool:
        """Return True if any of the pipeline items changed in the desired way."""
        if any(cls.did_change_diff(existing, new).values()):
            return True

        return False

    def __repr__(self):
        return "Book(title={}, author={}, avg_rating={:.2f}, custom_rating={}, nreview={}, len_descrip={}, language={}, ngenre={}, ndownload={}, created={})".format(self.title, self.author.name, self.avg_rating, self.custom_rating, self.num_reviews, len(self.description) if self.description is not None else 0, self.language, len(self.genres), len(self.downloaded_items), self.created)

class Genre(Base):
    """ GoodReads genres are simply strings, but a book can have many genres """

    __tablename__ = "genre"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False)

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Genre(name={})".format(self.name) # rate={:.5f}  --> what to do when rate is None?

class Award(Base):
    """ GoodReads awards are simply strings, but a book can win many awards """

    __tablename__ = "award"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False, unique=True)

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Award(name={})".format(self.name)

class Character(Base):
    """ GoodReads characters are simply strings, but a book can contain many characters """

    __tablename__ = "character"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False, unique=True)

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Character(name={})".format(self.name) # rate={:.5f}  --> what to do when rate is None?

class Place(Base):
    """ GoodReads places are simply strings, but a book can contain many places """

    __tablename__ = "place"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False, unique=True)

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "Place(name={})".format(self.name) # rate={:.5f}  --> what to do when rate is None?

class RatingHistogram(Base):
    """ GoodReads rating can be between 1 and 5 stars
        a RatingHistogram is the aggregating of all ratings, since I'm not saving rating entries
    """

    __tablename__ = "rating_histogram"
    id          = Column(Integer, primary_key=True)
    book_id     = Column(Integer, ForeignKey("book.id"))
    star1       = Column(Integer, nullable=True)
    star2       = Column(Integer, nullable=True)
    star3       = Column(Integer, nullable=True)
    star4       = Column(Integer, nullable=True)
    star5       = Column(Integer, nullable=True)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def rating_as_dict(self):
        # star_cols = [ getattr(self, c.name) for c in self.__table__.columns}]
        return {f"{i}": getattr(self, f"star{i}") for i in range(1,6)}

    def __repr__(self):
        return "RatingHistogram(book_title={}, rating_histogram={})".format(getattr(self.book, 'title', None), self.rating_as_dict()) # rate={:.5f}  --> what to do when rate is None?

class DownloadItemType(Base):
    """ DownloadItemType can be pdf, epub, mobi, ... """

    __tablename__ = "download_item_type"
    id      = Column(Integer, primary_key=True)
    name    = Column(String, nullable=False, unique=True)

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "DownloadItemType(name={})".format(self.name)

class DownloadItem(Base):
    """ DownloadItem represents a completed book download, with a (zlib) name, parent book id and a DownloadItemType """

    __tablename__   = "download_item"
    id              = Column(Integer, primary_key=True)
    book_id         = Column(Integer, ForeignKey("book.id"))
    book            = relationship("Book", uselist=False, lazy='selectin')
    tag             = Column(String, unique=False) # id from outside, to quickly fetch items
    zlib_name       = Column(String, nullable=False, unique=False)
    zlib_authors    = Column(String, nullable=True, unique=False)
    location        = Column(String, nullable=True, unique=False) # storage bucket address, optional
    file_name       = Column(String, nullable=True, unique=False) # file_name in the storage bucket
    file_type_id    = Column(Integer, ForeignKey("download_item_type.id"))
    file_type       = relationship("DownloadItemType", uselist=False, lazy='selectin')
    file_size_mb    = Column(Float)
    pct_done        = Column(Integer, unique=False, default=0)
    nupdate         = Column(Integer, unique=False, default=1)
    done            = Column(Boolean, unique=False, default=False)
    dummy           = Column(Boolean, unique=False, default=False)

    created = Column(DateTime, server_default=func.now()) # current_timestamp()
    updated = Column(DateTime, server_default=func.now(), onupdate=func.now())

    # add this so that it can be accessed
    __mapper_args__ = {"eager_defaults": True}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "DownloadItem(zlib_name={}, zlib_authors={}, book_title={}, file_type={}, file_name={}, file_size_mb={}, location={}, tag={}, pct_done={}, done={}, dummy={})".format(self.zlib_name, self.zlib_authors, getattr(self.book, 'title', None), self.file_type, self.file_name, self.file_size_mb, self.location, self.tag, self.pct_done, self.done, self.dummy)
