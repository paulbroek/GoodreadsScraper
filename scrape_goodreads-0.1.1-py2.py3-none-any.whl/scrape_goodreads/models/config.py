"""config.py.

import psql config from environment variables inside
    config/.db.test.env
or  config/.db.prod.env

which should be defined in settings.py / ./config/.test.env, under:

    SCRAPE_GOODREADS_CONFIG_FILE=/home/paul/repos/misc-scraping/misc_scraping/scrape_goodreads/config/.db.test.env
"""
import configparser
import os
from typing import Optional

from dotenv import load_dotenv
from rarc_utils.models.psql_config import psqlConfig

from ..settings import CONFIG_FILE_NAME, ENV_FILE

load_dotenv(ENV_FILE)

cfg_file: Optional[str] = os.environ.get(CONFIG_FILE_NAME)
assert cfg_file is not None
assert os.path.exists(cfg_file)


def load_config_file(dot_cfg_file: str) -> psqlConfig:
    """Load psql config from .cfg file."""
    assert os.path.exists(dot_cfg_file)

    parser = configparser.ConfigParser()
    parser.read(dot_cfg_file)

    from_cfg_file = {k.upper(): v for k, v in parser["psql"].items()}
    return psqlConfig(**from_cfg_file)


psql = load_config_file(cfg_file)
