"""psql_config.py.

postgresql configuration class to enforce strong typing on configurations 
passed from .db.{test,prod}.env files
"""

from attrs import field, fields_dict, frozen, validators


@frozen
class psqlConfig:
    """Psql configuration."""
    pg_host: str = field(validator=[validators.instance_of(str)])
    pg_port: int = field(converter=int)
    pg_user: str = field(validator=[validators.instance_of(str)])
    pg_passwd: str = field(validator=[validators.instance_of(str)])
    pg_db: str = field(validator=[validators.instance_of(str)])


psqlKeys = fields_dict(psqlConfig)
