"""helpers.py.

Helper methods for SQLAlchemy models
"""
import logging
from datetime import datetime, timedelta
from typing import List, Optional, Tuple

import pandas as pd
from sqlalchemy import func
from sqlalchemy.future import select  # type: ignore[import]
from tqdm import tqdm  # type: ignore[import]

from rarc_utils.sqlalchemy_base import \
    aget_str_mappings as aget_str_mappings_custom
from rarc_utils.sqlalchemy_base import create_many as create_many_custom
from rarc_utils.sqlalchemy_base import \
    get_str_mappings as get_str_mappings_custom

from ..settings import GOODREADS_PFX
from .main import Author, Base, Book, Character, DownloadItemType, Genre, Place

logger = logging.getLogger(__name__)


async def aget_str_mappings(
    psqConfig, models=(Genre, Character, Place, Author, DownloadItemType)
):
    """Get str mappings from pg asynchronously.

    Eample:
        str_mappings = asyncio.run(aget_str_mappings(psql))

    """
    return await aget_str_mappings_custom(psqConfig, models)


def get_str_mappings(
    psqConfig, models=(Genre, Character, Place, Author, DownloadItemType)
):
    """Get str mappings from pg.

    Eample:
        str_mappings = get_str_mappings_custom(s)

    """
    return get_str_mappings_custom(psqConfig, models)


async def set_download_item(item):
    """Add zlib downloaded item to a goodreads Book.

    this prevents you from duplicate downloading a zlib book
    """
    raise NotImplementedError


def any_dict(book, unpackMethod):
    method = getattr(book, unpackMethod)

    if callable(method):
        return method.__call__()

    return method


def get_all(
    session,
    model=Book,
    n=None,
    hours_ago=None,
    to="list",
    indexCol="updated",
    unpackMethod="as_dict",
):
    # assert issubclass(Base, model)
    assert type(Base) == type(model), f"{type(model)=}, should be DeclarativeMeta"
    assert to in (toTypes := ("list", "pandas")), f"{to=} not in {toTypes=}"
    stmt_ = session.query(model)

    if model is Book:
        stmt_ = stmt_.join(Author)

    # bres_ = list(session.execute(stmt_).scalars())
    if hours_ago is not None:
        # assert isinstance(hours_ago, int)
        hours_ago = int(hours_ago)
        from_date = datetime.utcnow() - timedelta(hours=hours_ago)
        from_date_str = from_date.strftime("%Y-%m-%d %H:%M")
        assert isinstance(from_date_str, str)
        bres_ = stmt_.filter(func.date(model.updated) >= from_date_str)
    elif n is None:
        bres_ = stmt_.all()
    else:
        bres_ = stmt_.order_by(model.created.desc()).limit(n)

    if to == "pandas":
        assert hasattr(model, unpackMethod), f"{model=} does not have {unpackMethod=}"
        df = pd.DataFrame(map(lambda book: any_dict(book, unpackMethod), bres_))
        df.index = pd.DatetimeIndex(df[indexCol])
        return df

    return bres_


def count_ndownload(session, hours=24) -> int:
    """Count the number of downloaded items for a given interval 'hours'."""
    hours = int(hours)
    query = f"""SELECT COUNT(*) FROM download_item WHERE done='t' AND updated  >= NOW() - '{hours} hour'::INTERVAL;"""

    res: List[int] = session.execute(query).fetchone()

    return res[0]


def get_download_items_by_book(session, book_id, file_type_id=None, is_done=False):
    """Get download items by book.

    optionally also by file_type_id
    """
    query = "SELECT COUNT(*) FROM download_item WHERE book_id={}".format(book_id)
    if is_done:
        query += " AND done='t'"
    if file_type_id is not None:
        assert isinstance(file_type_id, int), f"{type(file_type_id)=}, should be int"
        query += f" AND file_type_id={file_type_id}"

    res = session.execute(query).fetchone()

    return res[0]


def get_download_item_types(session) -> Tuple[dict, dict]:
    """Return dict and inverted dict for download_item_type.

    example:
     ({1: 'PDF', 2: 'EPUB'}, {'PDF': 1, 'EPUB': 2})

    """
    query = """ SELECT * FROM download_item_type; """

    res = session.execute(query).fetchall()

    return dict(res), dict(r[::-1] for r in res)


def nbook(session) -> int:
    """Get number of books in Book table."""
    query = """ SELECT count(*) FROM book; """

    res = session.execute(query).fetchone()

    if res is None:
        return 0

    return res[0]


def id_to_url(url_or_id: str) -> str:
    if url_or_id.startswith(GOODREADS_PFX):
        return url_or_id
    return "{}/book/show/{}".format(GOODREADS_PFX, url_or_id)


async def exists_goodreads_id(url_or_id: str, asession) -> bool:
    """Find if book exists by goodreads id."""
    assert isinstance(url_or_id, str)
    url: str = id_to_url(url_or_id)

    # `exists` not compatible with async sqlalchemy?
    # query_exists = exists().where(Book.url == url)
    query_exists = select(Book.id).where(Book.url == url)

    async with asession() as session:
        res = (await session.execute(query_exists)).fetchone()

    if res is None:
        return False

    return True


async def find_by_goodreads_id(url_or_id: str, asession) -> Optional[dict]:
    """Find books by goodreads id.

    First check if book exists, then run join query
    !! add index for faster look-up:
        CREATE INDEX book_url ON "book" (url);
    """
    assert isinstance(url_or_id, str)
    url: str = id_to_url(url_or_id)

    if not await exists_goodreads_id(url_or_id, asession):
        return None

    query_join = """SELECT book.*, author.name AS author_name FROM book
        INNER JOIN author ON author.id = book.author_id
        WHERE book.url = '{}';""".format(
        url
    )

    async with asession() as session:
        res = (await session.execute(query_join)).fetchone()

        if res is None:
            return res

        return res._asdict()


def get_download_items_by_book_id(book_id: int, session) -> Optional[List[dict]]:

    assert isinstance(book_id, int)

    query = """ SELECT DISTINCT di.book_id, di.zlib_name, di.done, dit.name AS di_type
                FROM download_item as di
                LEFT JOIN download_item_type AS dit ON dit.id = di.file_type_id
                WHERE di.book_id = {} AND di.done;
            """.format(
        book_id
    )

    res = session.execute(query).fetchall()

    if len(res) == 0:
        return None

    return [r._asdict() for r in res]


async def create_many(*args, **kwargs) -> None:
    """Create many of any model type: Character, Genre, Places, Author, etc.

    Todo:   filtering out existing names only works for Category models, author is unique by name + birth_date,
            so it needs a different implementation
    """
    # print `Book` items if less than 20
    kwargs["printCondition"] = (
        lambda model, items: model is Book and 0 < len(items) <= 20
    )

    return await create_many_custom(*args, **kwargs)


# asyncio.run(set_custom_rating(async_session))
async def set_custom_rating(async_session, maxRow=None) -> None:
    """Retrieve all books, and sets a custom_rating.

    what works for now: inverse quantile cut (qcut) books based on num_ratings
    and substract that value from the avg_rating

    so F_custom_rating(x) =  avg_rating + 0.2 - num_ratings_bin / 9
    """
    # use node api to request books
    # --> unsafe, it skips books without cover_image urls
    # response = requests.get('http://localhost:3001/books/')
    # books = json.loads(response.text)

    # retrieve book by id and update book.custom_rating
    async with async_session() as session:
        psql_res = await session.execute(select(Book))
        psql_books = list(psql_res.scalars())
        books = [b.as_dict() for b in psql_books]

        df = pd.DataFrame(books)
        df.index = df["id"]

        print(f"{df.head()[['title','avg_rating','id']]}")

        df["num_ratings_bin"] = pd.qcut(
            df.num_ratings, 10, labels=list(reversed(range(10)))
        )
        df["custom_rating"] = df.apply(
            lambda row: row["avg_rating"] + 0.2 - row["num_ratings_bin"] / 9, axis=1
        )

        # for row in tqdm(df.itertuples(), mininterval=2):
        for i, book in enumerate(tqdm(psql_books, mininterval=1)):
            # print(f'{book.title=}')
            # book = session.query(Book).get(row.id)
            book.custom_rating = df.loc[book.id].custom_rating

            if maxRow is not None and i > maxRow:
                break

        # update all books at once
        await session.commit()

        nupdated = len(df) if maxRow is None else maxRow
        logger.info(f"updated {nupdated:,} rows")


async def create_initial_items(async_session) -> None:

    async with async_session() as session:
        await create_many(
            session, Character, {a: dict(name=a) for a in ["tom", "tim", "ian", "bert"]}
        )
        await create_many(
            session, Genre, {a: dict(name=a) for a in ["Fiction", "Action"]}
        )
        await create_many(
            session, DownloadItemType, {a: dict(name=a) for a in ["PDF", "EPUB"]}
        )
